import handler from '../server';

// Vercel auto-detects any file under /api as a serverless function. This
// catch-all (`[...path]`) receives every request whose URL starts with
// /api/ -- e.g. /api/orders/create, /api/razorpay/order -- and hands it
// straight to the single shared Express app defined in server.ts, so all
// existing route definitions there keep working unchanged.
export default handler;

export const config = {
  api: {
    bodyParser: false, // server.ts's own express.json() handles body parsing
  },
};

// Force the Node runtime because server.ts uses Express, Firebase Admin SDK,
// Razorpay, and Node crypto APIs.
export const runtime = 'nodejs';
