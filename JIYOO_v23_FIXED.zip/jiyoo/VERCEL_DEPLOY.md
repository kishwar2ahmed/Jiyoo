# Deploying JIYOO to Vercel

## What changed to make this Vercel-compatible
- `server.ts` no longer only works as a long-running server. It now exports
  a request handler (`export default async function handler(...)`) that
  Vercel's serverless runtime can call per-request, while still calling
  `app.listen()` normally when run as a traditional Node process (Render,
  a VPS, `npm run dev` locally) — nothing about that path changed.
- `api/[...path].ts` is a thin Vercel entry point (Vercel auto-detects
  anything under `/api` as a function). It catches every request under
  `/api/*` and hands it straight to the same Express app in `server.ts` —
  every existing route (`/api/orders/create`, `/api/razorpay/order`, etc.)
  keeps working with zero changes to its logic.
- `vercel.json` tells Vercel to build the frontend with `vite build`,
  serve `dist/` as the static site, and treat `api/[...path].ts` as the
  serverless function for everything under `/api`.
- Fixed a real bug this surfaced: `/api/upload` used to write files to
  local disk (`public/uploads/`), which doesn't work on Vercel's read-only
  filesystem. It now always serves images back through the existing
  `/api/images/:id` Firestore-backed route, which works identically on
  Vercel and on a traditional server. (Note: your actual product-image
  uploads already went straight from the browser to Firebase Storage via
  `ImageUpload.tsx` and were never affected by this — this bug only lived
  in an unused legacy endpoint.)

## Deploy steps

1. Push this project to GitHub (see the earlier steps you already have).
2. Go to https://vercel.com → **"Add New" → "Project"** → import your
   GitHub repo.
3. Vercel will auto-detect the framework as **Vite**. Leave the build
   settings as-is (they come from `vercel.json`).
4. Add your environment variables under **Settings → Environment
   Variables** — same list as in `.env.example`:
   - All `VITE_FIREBASE_*` keys, including `VITE_FIREBASE_FIRESTORE_DATABASE_ID`
   - `FIREBASE_SERVICE_ACCOUNT_KEY` (paste the full service-account JSON
     as one line)
   - `FIREBASE_STORAGE_BUCKET`
   - `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` / `RAZORPAY_WEBHOOK_SECRET`
     (leave blank to disable online payments — COD/WhatsApp still work)
   - `SMTP_*` (leave blank to disable email notifications)
5. Click **Deploy**.

Vercel gives you a URL like `jiyoo.vercel.app`. Test:
- Open `/api/health` and confirm the named Firestore database is reported and both Firestore + Storage are `ok`.
- Admin → Settings → Save
- Admin → Products → add/edit product + upload image
- Admin → Orders → change a status
- Storefront → checkout with Cash on Delivery
- Storefront → Instant Order via WhatsApp
- Storefront → Razorpay checkout (requires Razorpay env vars)

The previous `Unexpected token 'T'` message was the frontend trying to parse an HTML response as JSON. The API function is explicitly present under `/api/[...path].ts`, and the client now detects non-JSON responses and reports them accurately instead of surfacing a misleading JSON syntax error.

## One limitation worth knowing
Vercel's free tier serverless functions have a cold-start delay (a second
or two) after a period of no traffic, and a max execution time per
request (`maxDuration: 30` seconds is set in `vercel.json`, safely above
anything this app does). For a store with steady traffic this is barely
noticeable. If you ever want a persistent, always-warm server instead,
the same `server.ts` also runs unmodified on Render/Railway/a VPS via
`npm run build && npm start`.
