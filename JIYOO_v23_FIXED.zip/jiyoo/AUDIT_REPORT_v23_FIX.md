# JIYOO v23 — Deep Audit & Fix Report

Date: 2026-08-20  
Source: uploaded `jiyoo_fixed_v23.zip`

## Executive result

The failure pattern in the screenshots is consistent with **two infrastructure/configuration mismatches plus several application-level robustness bugs**. The biggest code defect was a Firestore database-ID mismatch: `firebase.json` targeted a named Firestore database, while both the browser and server SDKs silently used `(default)`. Firebase SDKs default to `(default)` unless a database ID is specified.

The uploaded project has now been patched to use the named database explicitly and to make the database ID configurable. I also fixed admin-save behavior, Storage authorization for the named-database setup, missing admin rules, Vercel API handling, and WhatsApp mobile popup behavior.

**Important:** this audit was performed against the uploaded source archive. I cannot honestly mark the live Vercel deployment as verified because no live deployment URL/API response or Vercel environment-variable access was available in this run. The fixed archive is ready to deploy.

## Findings

### 1. CRITICAL — Firestore database mismatch

**Evidence:** `firebase.json` targets:

`ai-studio-bismillahbuild-b1ad3cd8-2593-4aba-a17a-3e92d91687d1`

But `src/services/firebase.ts` initialized Firestore without a database ID, and `server.ts` used `getFirestore()` without a database ID. Both default to `(default)`.

**Impact:** admin Products/Settings/Categories/Payments writes, user records, and server-side COD/WhatsApp/Razorpay order persistence could all fail when `(default)` does not exist.

**Fix:** both client and server now use the configured named database. Defaults match `firebase.json`; environment variables can override it.

### 2. CRITICAL — Storage rules depended on the wrong Firestore database

`storage.rules` used `firestore.exists(/databases/(default)/...)` for role-based admin authorization. Firebase documents that Storage Rules can only access the default Firestore database when multiple databases are active.

**Impact:** role-based admins could be denied image uploads even if Firestore itself was correctly configured as a named database.

**Fix:** Storage admin authorization now uses the explicit JIYOO admin email allow-list and no longer depends on a cross-service Firestore lookup.

### 3. HIGH — Admin product save closed before the write completed

`ProductsTab.handleSave()` closed the modal and cleared the form before awaiting Firestore. If the write failed, the admin lost the entered data and only saw a generic error.

**Fix:** modal closes only after a successful write; failed writes keep the form open and show the actual error. Added a 15-second timeout.

### 4. HIGH — Missing Firestore rules for admin collections

`messages` and `audit_logs` were used by admin components but had no explicit rules. The final catch-all rule denied them.

**Fix:** added admin-only rules for reading/deleting messages and immutable audit-log behavior.

### 5. HIGH — Vercel HTML response was parsed as JSON

The screenshot error `Unexpected token 'T' ... is not valid JSON` occurs when `res.json()` receives an HTML/text error page instead of JSON.

**Fixes:**
- retained the `/api/[...path].ts` Vercel function entry point;
- explicitly selected the Node.js runtime;
- added a shared `fetchJson()` parser that detects non-JSON responses and reports the HTTP status/content instead of throwing a misleading JSON syntax error.

### 6. HIGH — WhatsApp order could be blocked by mobile popup protection

Both WhatsApp flows called `window.open()` only after an asynchronous `/api/orders/create` request. Mobile browsers can block that as a popup because the user gesture has ended.

**Fix:** open a blank tab immediately from the click handler and navigate it to the generated WhatsApp URL after the server returns.

### 7. MEDIUM — sessionLogin read `req.body` before JSON middleware

The session-login routes were registered before `express.json()`.

**Fix:** JSON parsing middleware now runs immediately after the Express app is created, before session routes.

### 8. LOW — Wrong Firebase project name in admin error message

Settings error text referenced `jiyoo-33318`, which does not match the project configuration in the uploaded source.

**Fix:** replaced the misleading project-specific message with an actionable Firebase sync error.

## Payment audit

### Cash on Delivery

The COD route itself is structurally correct: client → `/api/orders/create` → authoritative server price calculation → Firestore order write → inventory transaction. The major blocker was the backend's Firestore connection.

**Code status after patch:** fixed at the database-connection layer.

### Razorpay

Razorpay order creation, signature verification, and webhook reconciliation are present. The server correctly fails closed if the webhook secret is missing.

**Code status after patch:** payment flow is wired; live payment availability still requires valid Vercel environment variables (`RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`) and a working Firebase Admin connection.

### WhatsApp Express

Order creation is server-side and now uses the same fixed Firestore database. The mobile popup issue was also fixed.

**Code status after patch:** fixed.

## Image upload audit

Product images are uploaded directly from the browser to Firebase Storage, not through the Vercel filesystem. That is the correct architecture for Vercel. The major rules problem was the Storage → Firestore authorization lookup against `(default)`.

**Code status after patch:** fixed for the configured admin email accounts, provided the Firebase Storage bucket exists and Storage Rules are deployed.

## Required Vercel environment configuration

Set these in Vercel Production:

- `VITE_FIREBASE_API_KEY`
- `VITE_FIREBASE_AUTH_DOMAIN`
- `VITE_FIREBASE_PROJECT_ID`
- `VITE_FIREBASE_STORAGE_BUCKET`
- `VITE_FIREBASE_MESSAGING_SENDER_ID`
- `VITE_FIREBASE_APP_ID`
- `VITE_FIREBASE_FIRESTORE_DATABASE_ID` = `ai-studio-bismillahbuild-b1ad3cd8-2593-4aba-a17a-3e92d91687d1`
- `FIREBASE_SERVICE_ACCOUNT_KEY` = complete service-account JSON
- `FIREBASE_STORAGE_BUCKET` = `jiyoo-7.firebasestorage.app`
- `FIREBASE_FIRESTORE_DATABASE_ID` = same database ID
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_WEBHOOK_SECRET`

## Post-deploy verification

Open:

`https://<your-deployed-domain>/api/health`

Expected: Firebase Admin initialized, Firestore write succeeds, and Storage bucket exists.

Then test in this order:

1. Admin Settings → change a harmless setting → Save → refresh → confirm persistence.
2. Admin Products → edit price/name → Save → refresh → confirm persistence.
3. Admin Products → upload a product image → Save → refresh → confirm image remains.
4. Checkout → COD → Place Order → confirm success and Admin Orders entry.
5. Checkout → WhatsApp → confirm WhatsApp opens and Admin Orders gets `whatsapp_pending`.
6. Checkout → Razorpay → test payment in the intended Razorpay environment and verify the order.

## Verification limitations in this environment

The uploaded archive did not contain a usable `node_modules/.bin` toolchain, and installing dependencies was not possible in this execution environment. Therefore a full `tsc`/Vite/esbuild production build could not be executed here. A TypeScript parser pass produced no syntax errors; remaining diagnostics were dependency/type-definition resolution errors caused by the missing installed packages.

The live Vercel deployment was also not directly accessible from the provided screenshot, so live API health/payment verification remains a deployment step rather than something I will falsely claim is already complete.
