export async function fetchJson<T = any>(input: RequestInfo | URL, init?: RequestInit): Promise<{ response: Response; data: T }> {
  const response = await fetch(input, init);
  const text = await response.text();
  const contentType = response.headers.get('content-type') || '';

  let data: any = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      const preview = text.replace(/\s+/g, ' ').trim().slice(0, 180);
      throw new Error(`API returned non-JSON response (HTTP ${response.status}). ${preview || 'No response body.'}`);
    }
  }

  if (!contentType.includes('application/json') && text) {
    throw new Error(`API returned an unexpected content type (HTTP ${response.status}).`);
  }

  return { response, data: data as T };
}
