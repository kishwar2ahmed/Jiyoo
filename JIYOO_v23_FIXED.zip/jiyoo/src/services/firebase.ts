import { initializeApp, setLogLevel } from 'firebase/app';
import { getAuth, GoogleAuthProvider, OAuthProvider } from 'firebase/auth';
import { initializeFirestore, getFirestore, memoryLocalCache } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getMessaging, isSupported as isMessagingSupported } from 'firebase/messaging';
import { getAnalytics, isSupported as isAnalyticsSupported } from 'firebase/analytics';

// Silence non-critical Firebase SDK log warnings
try {
  setLogLevel('silent');
} catch {
  // ignore
}

const REQUIRED_FIREBASE_ENV_VARS = [
  'VITE_FIREBASE_API_KEY',
  'VITE_FIREBASE_AUTH_DOMAIN',
  'VITE_FIREBASE_PROJECT_ID',
  'VITE_FIREBASE_STORAGE_BUCKET',
  'VITE_FIREBASE_MESSAGING_SENDER_ID',
  'VITE_FIREBASE_APP_ID',
] as const;

// JIYOO's Firebase project currently uses the named Firestore database
// configured in firebase.json. The Firestore SDK defaults to `(default)`,
// which caused every read/write to fail when that database did not exist.
// Keep the ID configurable so the project can be switched to `(default)`
// later without changing application code.
const FIRESTORE_DATABASE_ID =
  import.meta.env.VITE_FIREBASE_FIRESTORE_DATABASE_ID ||
  'ai-studio-bismillahbuild-b1ad3cd8-2593-4aba-a17a-3e92d91687d1';

const missingFirebaseEnvVars = REQUIRED_FIREBASE_ENV_VARS.filter(
  (key) => !import.meta.env[key]
);

if (missingFirebaseEnvVars.length > 0) {
  // Firebase client config isn't secret by design, but falling back silently here
  // means a misconfigured .env can point a local/staging build at production data
  // without anyone noticing. Fail loudly instead.
  console.error(
    `[Firebase Config] Missing env var(s): ${missingFirebaseEnvVars.join(', ')}. ` +
    `Falling back to hardcoded PRODUCTION Firebase credentials (project "jiyoo-7"). ` +
    `Set these in your .env file (see .env.example) if this is not intentional -- ` +
    `otherwise this build/dev-server is talking to the live production database.`
  );
}

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyBImeRxGJH124nDzdQUv-gDBfiQjV-vPxI',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'jiyoo-7.firebaseapp.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'jiyoo-7',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'jiyoo-7.firebasestorage.app',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '646981074808',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:646981074808:web:41b578dd129ba55fbfd28d',
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || 'G-3NSYCDJHD4'
};

// firebaseConfig initializes with VITE_ variables or active project defaults
const app = initializeApp(firebaseConfig);

let firestoreDb: ReturnType<typeof getFirestore>;

const firestoreConfig: any = {
  localCache: memoryLocalCache(),
  // Mobile browsers, in-app WebViews (e.g. opening the app inside another
  // app's built-in browser), and some networks block Firestore's default
  // WebChannel streaming connection without ever throwing an error — the
  // request just hangs forever, which is why Save/Update buttons got stuck
  // on their loading spinner with no success or error message. Auto-detecting
  // and falling back to long-polling fixes this.
  experimentalAutoDetectLongPolling: true,
  useFetchStreams: false,
};

try {
  firestoreDb = initializeFirestore(app, firestoreConfig, FIRESTORE_DATABASE_ID);
} catch (e) {
  try {
    firestoreConfig.localCache = memoryLocalCache();
    firestoreDb = initializeFirestore(app, firestoreConfig, FIRESTORE_DATABASE_ID);
  } catch (err) {
    firestoreDb = getFirestore(app, FIRESTORE_DATABASE_ID);
  }
}

export const db = firestoreDb;
export const firestoreDatabaseId = FIRESTORE_DATABASE_ID;
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const appleProvider = new OAuthProvider('apple.com');
export const storage = getStorage(app);

let analyticsInstance: any = null;
export const getAnalyticsInstance = async () => {
  if (analyticsInstance) return analyticsInstance;
  
  if (!import.meta.env.VITE_FIREBASE_API_KEY) {
    return null;
  }
  
  try {
    const supported = await isAnalyticsSupported();
    if (supported) {
      try {
        analyticsInstance = getAnalytics(app);
        return analyticsInstance;
      } catch (e) {
        console.warn('Analytics initialization failed (possibly invalid API key):', e);
        return null;
      }
    }
  } catch (error) {
    console.error('Analytics not supported in this environment:', error);
  }
  return null;
};

let messagingInstance: any = null;
export const getMessagingInstance = async () => {
  if (messagingInstance) return messagingInstance;
  
  if (!import.meta.env.VITE_FIREBASE_API_KEY) {
    return null;
  }
  
  try {
    const supported = await isMessagingSupported();
    if (supported) {
      try {
        messagingInstance = getMessaging(app);
        return messagingInstance;
      } catch (e) {
        console.warn('FCM initialization failed (possibly invalid API key):', e);
        return null;
      }
    }
  } catch (error) {
    console.error('FCM not supported:', error);
  }
  return null;
};

