import { getAuth } from 'firebase/auth';
import { createSingleProductWhatsAppUrl } from '../../../utils/whatsapp';
import { useToast } from '../../core/contexts/ToastContext';
import { fetchJson } from '../../../utils/api';

export function useWhatsAppOrder() {
  const { showToast } = useToast();
  const handleWhatsAppOrder = async ({
    product,
    user,
    settings,
    quantity,
    currentPrice,
    currentUnit,
    selectedCut
  }: any) => {
    if (!product) return null;

    // Route through /api/orders/create -- firestore.rules forbids writing to
    // `orders` directly from the browser, and the server assigns the order ID/price.
    let orderId: string | null;
    const whatsappWindow = typeof window !== 'undefined' ? window.open('about:blank', '_blank') : null;
    try {
      const auth = getAuth();
      const token = auth.currentUser ? await auth.currentUser.getIdToken() : null;
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const { response: res, data } = await fetchJson<any>('/api/orders/create', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          items: [{
            id: product.id,
            baseId: (product as any).baseId,
            name: product.name,
            quantity,
            price: currentPrice,
            image: product.image,
            selectedWeight: currentUnit || null,
            selectedCut: selectedCut || null,
          }],
          shippingDetails: {
            name: user?.name || '',
            phone: (user as any)?.phone || '',
            address: '',
            pincode: '',
          },
          paymentMethod: 'WhatsApp Express',
          userId: user?.id || 'guest',
        }),
      });

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to create order on server');
      }
      orderId = data.orderId;
    } catch (e: any) {
      if (whatsappWindow && !whatsappWindow.closed) whatsappWindow.close();
      console.error('Failed to create WhatsApp order:', e);
      showToast(e.message || 'Failed to generate order reference. Please try again.', 'error');
      return null;
    }

    const url = createSingleProductWhatsAppUrl({
      orderId: orderId || undefined,
      customerName: user?.name,
      customerPhone: user?.phone,
      whatsappNumber: settings.whatsappNumber,
      productName: product.name,
      quantity,
      selectedWeight: currentUnit,
      selectedCut: selectedCut || undefined,
      totalPrice: currentPrice * quantity
    });
    if (whatsappWindow && !whatsappWindow.closed) {
      whatsappWindow.location.href = url;
    } else {
      window.location.href = url;
    }

    return { url, orderId };
  };
  return { handleWhatsAppOrder };
}
