# JIYOO — Firestore Configuration Fix

## Root cause found in v23

The repository contains a **named Firestore database** in `firebase.json`:

`ai-studio-bismillahbuild-b1ad3cd8-2593-4aba-a17a-3e92d91687d1`

But the application code was connecting to Firestore's default `(default)` database. Firebase client and Admin SDKs default to `(default)` unless a database ID is supplied. That mismatch can produce `The database (default) does not exist`, which explains the admin save failures and COD/WhatsApp server failures. Firebase documents that named databases must be explicitly selected by database ID.

## Fix applied

- Browser Firestore now initializes against the named database from `VITE_FIREBASE_FIRESTORE_DATABASE_ID`.
- Server Firestore now uses `FIREBASE_FIRESTORE_DATABASE_ID`.
- The value defaults to the database already declared in `firebase.json`, so no source-code edit is required.
- Added a `/api/health` diagnostic that reports the configured database ID and tests Firestore/Storage.
- Storage Rules no longer depend on a Firestore lookup because Storage Security Rules can only access the default Firestore database when multiple databases exist. Admin uploads now authorize against the explicit admin email allow-list.
- Added missing admin rules for `messages` and `audit_logs`.

## Vercel environment variables

Set these for **Production** (and Preview if you test Preview deployments):

- `VITE_FIREBASE_API_KEY`
- `VITE_FIREBASE_AUTH_DOMAIN`
- `VITE_FIREBASE_PROJECT_ID`
- `VITE_FIREBASE_STORAGE_BUCKET`
- `VITE_FIREBASE_MESSAGING_SENDER_ID`
- `VITE_FIREBASE_APP_ID`
- `VITE_FIREBASE_FIRESTORE_DATABASE_ID` = `ai-studio-bismillahbuild-b1ad3cd8-2593-4aba-a17a-3e92d91687d1`
- `FIREBASE_SERVICE_ACCOUNT_KEY` = full Firebase service-account JSON
- `FIREBASE_STORAGE_BUCKET` = `jiyoo-7.firebasestorage.app`
- `FIREBASE_FIRESTORE_DATABASE_ID` = same database ID
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_WEBHOOK_SECRET`

Do not put the service-account JSON or Razorpay secret in any `VITE_*` variable.

## Verification URL

After deployment, open `/api/health` on the deployed JIYOO domain. It should report:

- `firebaseAdminInitialized: true`
- Firestore: `ok -- write succeeded`
- Storage: `ok -- bucket exists`

If Firestore fails, the report now shows the exact configured database ID instead of making you guess.

## Important

Do **not** create a second database just because the application says `(default)` was missing. First make sure the application and deployment are pointing at the database that actually contains the JIYOO data.
