# Setup Guide

## Prerequisites
- Node.js >= 20.19.0
- A Firebase project
- A Razorpay account

## 1. Firebase Configuration
1. Go to the Firebase Console and create a new project.
2. Enable Firestore, Firebase Storage, and Firebase Authentication.
3. In Authentication, enable Email/Password, Google, and Apple sign-in providers.
4. Go to Project Settings > General > Your apps and create a Web App.
5. Copy the configuration and place the values in `.env.local` (see `.env.example`).
6. Deploy the Firestore rules from `firestore.rules` and Storage rules from `storage.rules`.

## 2. Environment Variables
Create a `.env.local` file based on `.env.example`:
```
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_auth_domain
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_storage_bucket
VITE_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
VITE_FIREBASE_APP_ID=your_app_id
VITE_FIREBASE_MEASUREMENT_ID=your_measurement_id

RAZORPAY_KEY_ID=your_razorpay_key_id
RAZORPAY_KEY_SECRET=your_razorpay_key_secret
RAZORPAY_WEBHOOK_SECRET=your_webhook_secret

FIREBASE_SERVICE_ACCOUNT_KEY=your_service_account_json
SMTP_HOST=your_smtp_host
SMTP_PORT=587
SMTP_USER=your_smtp_user
SMTP_PASS=your_smtp_pass
```

## 3. Razorpay Setup
1. Log into your Razorpay Dashboard.
2. Go to Settings > API Keys and generate test/live keys.
3. Add `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` to your environment variables.
4. Go to Settings > Webhooks and add your deployed webhook URL (e.g., `https://yourdomain.com/.netlify/functions/webhook`).
5. Add the `RAZORPAY_WEBHOOK_SECRET` to your environment variables.

## Manual Setup Checklist
Before deploying, please manually verify and complete these steps:
- [ ] Upgrade Firebase Project to the Blaze (Pay-as-you-go) plan if using Netlify functions, Google Maps APIs, or certain other integrations.
- [ ] Whitelist your production domain in the Firebase Console (Authentication > Settings > Authorized domains).
- [ ] Verify you have switched your Razorpay keys from Test Mode to Live Mode when launching.
- [ ] Configure Razorpay Webhooks in the Razorpay dashboard with the production endpoint.
- [ ] Check `.env.example` and ensure every value has been populated in your `.env.local` locally and in Netlify's Environment Variables panel.
- [ ] Ensure SMTP email credentials are fully populated if sending email notifications.
