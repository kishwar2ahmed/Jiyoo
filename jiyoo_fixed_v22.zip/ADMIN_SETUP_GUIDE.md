# JIYOO Store — Complete Setup Guide (No Prior Experience Needed)

Follow these steps in order. Each one builds on the last — don't skip any.

You will need a **laptop or computer** (this cannot be done from a phone).

---

## PART 1: Create a GitHub Account

GitHub is where your website's code will live.

1. Go to **https://github.com**
2. Click **"Sign up"**
3. Enter your email, create a password, choose a username
4. Verify your email when GitHub sends you a code

---

## PART 2: Create a New Repository (a project folder on GitHub)

1. Once logged in, go to **https://github.com/new**
2. **Repository name:** type `jiyoo`
3. Click **"Private"** (important — keeps your code hidden from the public)
4. Leave everything else as default — do NOT check "Add a README"
5. Click the green **"Create repository"** button
6. GitHub will show you a page with some commands — **leave this tab open**, you'll need it in Part 4

---

## PART 3: Install Git on Your Computer

Git is a free tool that uploads code to GitHub.

1. Go to **https://git-scm.com/downloads**
2. Download the version for your operating system (Windows/Mac)
3. Install it — keep clicking "Next" with default options, no need to change anything

To check it worked, open:
- **Windows:** search for "Command Prompt" or "Git Bash" in the Start menu
- **Mac:** open "Terminal" (search with Spotlight, Cmd+Space)

Type this and press Enter:
```
git --version
```
If it shows a version number, you're good.

---

## PART 4: Upload the Website Code to GitHub

1. Extract (unzip) the `jiyoo_fixed_v21.zip` file you received into a folder on your Desktop — call the folder `jiyoo`

2. Open Terminal / Command Prompt / Git Bash

3. Navigate into that folder. Type (adjust the path to wherever you saved it):
```
cd Desktop/jiyoo
```
Press Enter.

4. Now run these commands **one at a time**, pressing Enter after each and waiting for it to finish:

```
git init
```
```
git add .
```
```
git commit -m "Initial upload"
```
```
git branch -M main
```
```
git remote add origin https://github.com/YOUR-USERNAME/jiyoo.git
```
   *(Replace `YOUR-USERNAME` with your actual GitHub username — you can copy the exact link from the GitHub page you left open in Part 2)*

```
git push -u origin main
```

5. It may ask you to log in to GitHub in a browser window — just follow the prompts and allow access.

6. Once done, refresh your GitHub repository page in the browser — you should see all your project files listed there.

---

## PART 5: Create a Vercel Account (this is what makes your site live)

1. Go to **https://vercel.com**
2. Click **"Sign Up"**
3. Choose **"Continue with GitHub"** — this links Vercel directly to your GitHub account (easiest option)
4. Approve the permission request

---

## PART 6: Deploy Your Website

1. On the Vercel dashboard, click **"Add New"** → **"Project"**
2. Under "Import Git Repository," find **`jiyoo`** in the list and click **"Import"**
3. Vercel will auto-detect the framework as **Vite** — leave this as is, don't change it
4. Click to expand **"Environment Variables"** — this is important, you must add these before deploying:

   Add each of the following (Name on the left, Value on the right). Get these values from your Firebase Console (https://console.firebase.google.com) → your project → ⚙️ Project Settings:

   | Name | Where to find the value |
   |---|---|
   | `VITE_FIREBASE_API_KEY` | Project Settings → General → "Your apps" section |
   | `VITE_FIREBASE_AUTH_DOMAIN` | Same place |
   | `VITE_FIREBASE_PROJECT_ID` | Same place |
   | `VITE_FIREBASE_STORAGE_BUCKET` | Same place |
   | `VITE_FIREBASE_MESSAGING_SENDER_ID` | Same place |
   | `VITE_FIREBASE_APP_ID` | Same place |
   | `FIREBASE_SERVICE_ACCOUNT_KEY` | Project Settings → Service Accounts tab → "Generate new private key" button → open the downloaded file, copy its ENTIRE contents as one line |
   | `FIREBASE_STORAGE_BUCKET` | Same as `VITE_FIREBASE_STORAGE_BUCKET` above |

   You can leave `RAZORPAY_*` and `SMTP_*` blank for now — the site works fine without them (customers can still use Cash on Delivery / WhatsApp ordering).

5. Click the black **"Deploy"** button

6. Wait 1–2 minutes. When it finishes, you'll see **"Congratulations"** with a screenshot of your live site.

---

## PART 7: Set Up Your Database (Firestore)

Your website needs a database to store products, orders, and settings.

1. Go to **https://console.firebase.google.com**
2. Select your project (should be named something like `jiyoo-7`)
3. In the left sidebar, click **"Firestore Database"**
4. If it says **"Create database"**, click it
5. Choose **"Production mode"**
6. Choose a location close to you (e.g. `asia-south1` for India)
7. Click **"Create"** — wait about a minute

Then also enable Storage (for image uploads):
1. Left sidebar → **"Storage"**
2. Click **"Get started"** if prompted
3. Accept the defaults, click **"Done"**

Both of these are **free** — no credit card, no payment plan needed for a store this size.

---

## PART 8: Test Everything

Visit your new Vercel URL (something like `jiyoo-hzab.vercel.app`) and check:

- [ ] The homepage loads and shows products
- [ ] Log into the Admin Panel and change a setting → click Save → confirm it works
- [ ] Go to Orders tab → try changing an order's status
- [ ] Add a product to cart → checkout using **Cash on Delivery** → confirm the order goes through
- [ ] Check that the new order appears in the Admin → Orders tab

If everything above works, your store is fully live and functional.

---

## If Something Goes Wrong

Take a screenshot of exactly where you got stuck (the error message, the page you're on) and send it along with this guide — that's the fastest way to get help, rather than describing it in words.

**Common gotcha:** If you ever need to update the code again later, always update it through Git commands (Part 4) or by editing directly on GitHub's website and committing — never delete and re-upload files by drag-and-drop, as that can leave old broken files mixed in with new ones.
