# Security Guidelines

## Firebase Security
- **Firestore Rules**: Strict matching in `firestore.rules`.
  - Collections like `/settings/{settingId}` use `allow write: if isAdmin();`.
  - Only authenticated admin users can modify sensitive settings.
  - Normal users can read products, categories, reviews, etc.
- **Storage Rules**: Strict matching in `storage.rules`.
  - Only authenticated admins can write to `/settings/{imageId}`.
- **Authentication**: Firebase Authentication manages sessions.
  - Role-based checking (`isAdmin()`) occurs in Firestore rules.
  - An Admin role is either assigned in the `users` collection or matches hardcoded emails.

## Environment Variables
- Secrets such as `FIREBASE_SERVICE_ACCOUNT_KEY` and Razorpay keys (`RAZORPAY_KEY_SECRET`) should remain strictly server-side (Netlify Functions or Express).
- `VITE_` prefixed variables (like the Firebase config) are exposed to the client side.

## General
- Prevent Cross-Site Scripting (XSS) by treating user input as untrusted.
- Maintain `npm` packages with up-to-date versions using `npm audit`.
