# ⚠️ CRITICAL: Admin & COD Not Working — Firestore Database Missing

## Problem
- Admin panel settings don't save
- Order status updates fail
- Cash on Delivery orders fail
- All client-side writes to Firestore fail silently

## Root Cause
**Your Firebase project (jiyoo-7) does NOT have a Firestore Database provisioned.**

The code is correct. Firestore is initialized on the client (`src/services/firebase.ts`), and the backend (`server.ts`) uses Firebase Admin SDK. But if the database doesn't exist, all writes fail.

---

## FIX: Create Firestore Database (2 minutes)

### Step 1: Go to Firebase Console
https://console.firebase.google.com/project/jiyoo-7

### Step 2: Click "Firestore Database" (left sidebar)
- If it says **"Create database"** → click it
- Choose **"Production mode"**
- Choose location **"asia-south1"** (closest to India)
- Click **"Create"**

Wait ~1 minute for it to initialize.

### Step 3: Enable Storage (optional but needed for admin uploads)
- In Firebase Console, click **"Storage"** (left sidebar)
- If it says **"Get Started"** → click it
- Accept defaults
- Click **"Done"**

### Step 4: Test Admin Portal
1. Refresh admin portal
2. Change any setting (e.g., store name)
3. Click **"Save Settings"**
4. Should see: ✅ "Store settings saved successfully!"

### Step 5: Test Order Status Update
1. Go to **Orders** tab
2. Pick any order
3. Click status dropdown → pick a new status
4. Should update instantly

### Step 6: Test COD
1. Go to storefront (not admin)
2. Add product to cart
3. Checkout with **Cash on Delivery**
4. Order should complete
5. Check **Admin → Orders** — order should appear

---

## Verification Checklist
- [ ] Firestore Database exists and shows **"production mode"**
- [ ] Storage bucket exists
- [ ] Admin settings save without errors
- [ ] Order status updates work
- [ ] COD orders appear in admin panel

---

## If Still Failing

Check browser console for errors:

### If you see: `"The database (default) does not exist"`
→ Firestore database not created (re-do Step 1-2 above)

### If you see: `"Missing or insufficient permissions"`
→ Security rules are blocking you. Run this in Firebase Console → Firestore → **Rules** tab:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    function isHardcodedAdmin() {
       return request.auth != null && "email" in request.auth.token && 
              (request.auth.token.email == 'yoyokishwar@gmail.com' || request.auth.token.email == 'jiyooshams@gmail.com' || request.auth.token.email == 'shamsjiyoo@gmail.com');
    }

    function isAdmin() {
      return isHardcodedAdmin() ||
        (exists(/databases/$(database)/documents/users/$(request.auth.uid)) && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin');
    }

    match /users/{userId} {
      allow read: if request.auth != null && (request.auth.uid == userId || isAdmin());
      allow create: if request.auth != null && request.auth.uid == userId && (isHardcodedAdmin() || request.resource.data.get('role', 'user') != 'admin');
      allow update: if isAdmin() || (request.auth != null && request.auth.uid == userId && request.resource.data.get('role', 'user') == resource.data.get('role', 'user'));
      allow delete: if isAdmin();
    }

    match /products/{productId} {
      allow read: if true;
      allow write: if isAdmin();
    }
    
    match /categories/{categoryId} {
      allow read: if true;
      allow write: if isAdmin();
    }
    
    match /coupons/{couponId} {
      allow read: if isAdmin();
      allow write: if isAdmin();
    }
    
    match /settings/{settingId} {
      allow read: if true;
      allow write: if isAdmin();
    }

    match /orders/{orderId} {
      allow read: if isAdmin() || (request.auth != null && resource.data.userId == request.auth.uid);
      allow create: if false;
      allow update: if isAdmin();
      allow delete: if isAdmin();
    }
    
    match /reviews/{reviewId} {
      allow read: if true;
      allow create: if request.auth != null &&
        request.resource.data.userId == request.auth.uid &&
        request.resource.data.rating is number &&
        request.resource.data.rating >= 1 &&
        request.resource.data.rating <= 5 &&
        request.resource.data.comment is string &&
        request.resource.data.comment.size() <= 2000;
      allow update, delete: if isAdmin();
    }
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

Then click **"Publish"**

---

## Why This Happened
The code expected Firestore to exist. Your `.env` is configured correctly, Firebase SDK is initialized, but the actual Firestore Database wasn't created in the Firebase Console.

This is a one-time setup issue, not a code bug. Once Firestore is created, everything works.
