# Database Schema (Firestore)

## Collection: `users`
**Document ID**: Firebase Auth UID
**Description**: Stores user profiles.
**Fields**:
- `email` (string): User's email
- `name` (string): Full name
- `role` (string): 'customer' or 'admin'
- `phone` (string): Contact number
- `address` (string): Shipping address
- `createdAt` (timestamp): Date created
- `fcmTokens` (array of strings): Device tokens for push notifications

## Collection: `products`
**Document ID**: Auto-generated string
**Description**: E-commerce products.
**Fields**:
- `name` (string): Product title
- `price` (number): Selling price
- `originalPrice` (number): Price before discount
- `discount` (number): Discount percentage
- `image` (string): URL to product image
- `category` (string): Category ID
- `stock` (number): Inventory count
- `isPopular` (boolean): Flag for featured section

## Collection: `categories`
**Document ID**: Auto-generated string
**Description**: Hierarchical categories structure.
**Fields**:
- `label` (string): Display name
- `items` (array of objects): Subcategories

## Collection: `orders`
**Document ID**: Auto-generated string
**Description**: Customer orders.
**Fields**:
- `userId` (string): UID of customer
- `amount` (number): Total order value in INR
- `items` (array): List of ordered product objects with `id`, `name`, `quantity`, `price`
- `shippingDetails` (object): User's shipping `name`, `phone`, `address`
- `status` (string): 'pending', 'confirmed', 'shipped', 'delivered', 'cancelled'
- `razorpay_order_id` (string): Gateway order ID
- `createdAt` (timestamp): Order creation date

## Collection: `settings`
**Document ID**: Specific setting IDs like `general`, `appearance`
**Description**: App-wide configuration.
**Fields**:
- `developerImageUrl` (string): URL for the Developer image
- `storeName` (string): Store title
- `currency` (string): Display currency
