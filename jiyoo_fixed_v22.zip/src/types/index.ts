export interface WeightOption {
  weight?: string;
  label?: string;
  price: string | number;
  originalPrice?: string | number;
}

export interface Product {
  id: string | number;
  baseId?: string | number;
  name: string;
  subtitle?: string;
  description?: string;
  price: string | number;
  numericPrice?: number;
  originalPrice?: string | number;
  discount?: number;
  unit?: string;
  selectedWeight?: string;
  selectedCut?: string;
  selectedCleaning?: string;
  image: string;
  images?: string[];
  badge?: string;
  freshnessBadge?: string;
  deliveryEstimate?: string;
  rating?: number;
  reviewsCount?: number;
  isOrganic?: boolean;
  isPopular?: boolean;
  category?: string;
  categoryId?: string;
  subcategory?: string;
  subcategoryId?: string;
  subsubcategory?: string;
  subSubcategoryId?: string;
  weights?: WeightOption[];
  origin?: string;
  tags?: string[];
  features?: string[];
  isMeatProduct?: boolean;
  fishCuts?: string[];
  cleaningOptions?: string[];
  cutType?: string;
  stock?: number;
  slug?: string;
  mrp?: string | number;
  stockStatus?: 'in_stock' | 'out_of_stock';
}

export type CartProduct = Product;

export interface SubSubCategory {
  id: string;
  label: string;
}

export interface SubCategory {
  id: string;
  label: string;
  items?: SubSubCategory[];
}

export interface Category {
  id: string;
  label: string;
  items?: SubCategory[];
}

export interface CartItem {
  id: string | number;
  name: string;
  price: string | number;
  numericPrice: number;
  unit?: string;
  image: string;
  quantity: number;
  selectedWeight?: string;
  selectedCut?: string;
}

export interface AuthUser {
  id: string;
  email: string;
  name?: string;
  displayName?: string;
  picture?: string;
  role?: string;
  phone?: string;
  address?: string;
  pincode?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address?: string;
  pincode?: string;
  role?: 'admin' | 'customer';
  createdAt?: { seconds: number; nanoseconds: number } | string | number | Date;
}

export interface Order {
  id: string;
  orderId?: string;
  userId: string;
  amount: number;
  subtotal?: number;
  deliveryFee?: number;
  grandTotal?: number;
  items: Array<{
    id: string | number;
    name: string;
    quantity: number;
    price: number;
    image?: string;
    selectedWeight?: string;
    selectedCut?: string;
  }>;
  shippingDetails: {
    name: string;
    phone: string;
    address: string;
    pincode?: string;
  };
  paymentMethod?: string;
  utrNumber?: string;
  status: string;
  orderStatus?: 'pending' | 'confirmed' | 'packed' | 'dispatched' | 'out_for_delivery' | 'delivered' | 'cancelled' | string;
  paymentStatus?: 'unpaid' | 'payment_pending' | 'paid' | 'refunded' | 'failed' | string;
  createdAt: { seconds: number; nanoseconds: number } | string | number | Date;
  updatedAt?: { seconds: number; nanoseconds: number } | string | number | Date;
  razorpay_order_id?: string;
  razorpay_payment_id?: string;
  discountAmount?: number;
  couponCode?: string | null;
  stockConflict?: boolean;
  stockConflictReason?: string;
  cancelReason?: string;
  createdViaWebhook?: boolean;
}
