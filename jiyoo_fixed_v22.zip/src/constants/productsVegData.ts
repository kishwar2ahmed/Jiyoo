import { Product } from '../types/index';

export const VEG_MEAT_SMOOTHIE_PRODUCTS: Product[] = [
  // =========================================================
  // 2. VEGETABLES AND HERBS (49 PRODUCTS)
  // =========================================================
  {
    id: 'v_onion',
    name: 'Onion',
    slug: 'onion',
    description: 'Fresh, pungent, and versatile Indian pink onions harvested from premier agricultural farms.',
    price: 59,
    numericPrice: 59,
    mrp: 69,
    unit: '1kg',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://placehold.co/500x500/E7E3DA/8A8170?text=Onion',
    tags: ['Indian', 'Pungent', 'Essential'],
    freshnessBadge: 'Farm Direct',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1kg', price: 59 },
      { label: '2kg', price: 109 }
    ]
  },
  {
    id: 'v_potato',
    name: 'Potato',
    slug: 'potato',
    description: 'Premium Indian potatoes with smooth skin, ideal for boiling, frying, or curry bases.',
    price: 49,
    numericPrice: 49,
    mrp: 59,
    unit: '1kg',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_potato.jpg',
    tags: ['Indian', 'Starch'],
    freshnessBadge: 'Fresh Harvest',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1kg', price: 49 },
      { label: '2kg', price: 89 }
    ]
  },
  {
    id: 'v_carrot',
    name: 'Carrot',
    slug: 'carrot',
    description: 'Crisp, sweet orange carrots packed with natural beta-carotene and dietary fiber.',
    price: 89,
    numericPrice: 89,
    mrp: 99,
    unit: '1kg',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://placehold.co/500x500/E7E3DA/8A8170?text=Carrot',
    tags: ['Indian', 'Crisp', 'Beta-Carotene'],
    freshnessBadge: 'Daily Pick',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 49 },
      { label: '1kg', price: 89 }
    ]
  },
  {
    id: 'v_baby_carrot',
    name: 'Baby Carrot',
    slug: 'baby-carrot',
    description: 'Tender, sweet baby carrots harvested early for optimal bite and snacking texture.',
    price: 69,
    numericPrice: 69,
    mrp: 79,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_baby_carrot.jpg',
    tags: ['Exotic', 'Tender', 'Baby Veg'],
    freshnessBadge: 'Gourmet',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '250g', price: 69 }
    ]
  },
  {
    id: 'v_radish',
    name: 'Radish',
    slug: 'radish',
    description: 'Crisp white radish (Mooli) with sharp zesty flavor and crunchy texture.',
    price: 49,
    numericPrice: 49,
    mrp: 59,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_radish.jpg',
    tags: ['Indian', 'Crisp'],
    freshnessBadge: 'Farm Fresh',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 49 }
    ]
  },
  {
    id: 'v_red_radish',
    name: 'Red Radish',
    slug: 'red-radish',
    description: 'Peppery red-skinned globe radishes with crisp white interior, excellent for fresh salads.',
    price: 59,
    numericPrice: 59,
    mrp: 69,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_red_radish.jpg',
    tags: ['Exotic', 'Peppery', 'Salad'],
    freshnessBadge: 'Fresh Pick',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '250g', price: 59 }
    ]
  },
  {
    id: 'v_baby_radish',
    name: 'Baby Radish',
    slug: 'baby-radish',
    description: 'Miniature baby radishes featuring mild peppery bite and vibrant crunch.',
    price: 69,
    numericPrice: 69,
    mrp: 79,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_baby_radish.jpg',
    tags: ['Exotic', 'Baby Veg'],
    freshnessBadge: 'Tender Harvest',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '250g', price: 69 }
    ]
  },
  {
    id: 'v_beetroot',
    name: 'Beetroot',
    slug: 'beetroot',
    description: 'Deep ruby-red beetroots rich in natural earthy sweetness and dietary nitrates.',
    price: 49,
    numericPrice: 49,
    mrp: 59,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_beetroot.jpg',
    tags: ['Indian', 'Earthy', 'Ruby Red'],
    freshnessBadge: 'Daily Fresh',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 49 }
    ]
  },
  {
    id: 'v_baby_beetroot',
    name: 'Baby Beetroot',
    slug: 'baby-beetroot',
    description: 'Tender baby beetroots harvested for quick roasting and gourmet salad plating.',
    price: 69,
    numericPrice: 69,
    mrp: 79,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_baby_beetroot.jpg',
    tags: ['Exotic', 'Gourmet'],
    freshnessBadge: 'Tender',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '250g', price: 69 }
    ]
  },
  {
    id: 'v_turnip',
    name: 'Turnip',
    slug: 'turnip',
    description: 'Purple-topped white turnips (Shalgam) offering crisp texture and mild peppery sweetness.',
    price: 59,
    numericPrice: 59,
    mrp: 69,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://placehold.co/500x500/E7E3DA/8A8170?text=Turnip',
    tags: ['Indian', 'Turnip'],
    freshnessBadge: 'Fresh Pick',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 59 }
    ]
  },
  {
    id: 'v_purple_potato',
    name: 'Purple Potato',
    slug: 'purple-potato',
    description: 'Vibrant purple-fleshed specialty potatoes rich in anthocyanin plant antioxidants.',
    price: 99,
    numericPrice: 99,
    mrp: 119,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_purple_potato.jpg',
    tags: ['Exotic', 'Purple Flesh', 'Specialty'],
    freshnessBadge: 'Exotic Grade',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 99 }
    ]
  },
  {
    id: 'v_blue_potato',
    name: 'Blue Potato',
    slug: 'blue-potato',
    description: 'Rare blue heirloom potato variety with nutty flavor and striking deep indigo hue.',
    price: 149,
    numericPrice: 149,
    mrp: 169,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_blue_potato.jpg',
    tags: ['Exotic', 'Heirloom'],
    freshnessBadge: 'Rare Find',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 149 }
    ]
  },
  {
    id: 'v_black_potato',
    name: 'Black Potato',
    slug: 'black-potato',
    description: 'Dark-skinned gourmet black potatoes featuring creamy texture and rich earthy flavor.',
    price: 149,
    numericPrice: 149,
    mrp: 169,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_black_potato.jpg',
    tags: ['Exotic', 'Gourmet'],
    freshnessBadge: 'Rare Find',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 149 }
    ]
  },
  {
    id: 'v_sweet_potato',
    name: 'Sweet Potato',
    slug: 'sweet-potato',
    description: 'Naturally sweet orange-fleshed sweet potatoes (Shakarkandi), rich in complex carbohydrates.',
    price: 89,
    numericPrice: 89,
    mrp: 99,
    unit: '1kg',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_sweet_potato.jpg',
    tags: ['Indian', 'Shakarkandi', 'Sweet'],
    freshnessBadge: 'Farm Direct',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 49 },
      { label: '1kg', price: 89 }
    ]
  },
  {
    id: 'v_yellow_ginger',
    name: 'Yellow Ginger',
    slug: 'yellow-ginger',
    description: 'Pungent, fibrous yellow ginger root providing robust aromatic heat for culinary curries.',
    price: 49,
    numericPrice: 49,
    mrp: 59,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_yellow_ginger.jpg',
    tags: ['Indian', 'Ginger', 'Pungent'],
    freshnessBadge: 'Fresh Root',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '250g', price: 49 }
    ]
  },

  // GREENS, BRASSICAS & ALLIUMS (13)
  {
    id: 'v_spinach',
    name: 'Spinach',
    slug: 'spinach',
    description: 'Fresh green spinach (Palak) leaves, washed and trimmed for quick cooking.',
    price: 39,
    numericPrice: 39,
    mrp: 49,
    unit: '1 bunch',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://placehold.co/500x500/E7E3DA/8A8170?text=Spinach',
    tags: ['Indian', 'Palak', 'Greens'],
    freshnessBadge: 'Daily Harvest',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1 bunch', price: 39 }
    ]
  },
  {
    id: 'v_lettuce',
    name: 'Lettuce',
    slug: 'lettuce',
    description: 'Crisp green leaf lettuce head harvested fresh for crunchy salad bowls.',
    price: 69,
    numericPrice: 69,
    mrp: 79,
    unit: '1 head',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_lettuce.jpg',
    tags: ['Indian', 'Lettuce', 'Salad'],
    freshnessBadge: 'Hydroponic',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1 head', price: 69 }
    ]
  },
  {
    id: 'v_mini_lettuce',
    name: 'Mini Lettuce',
    slug: 'mini-lettuce',
    description: 'Compact, tender mini lettuce hearts harvested for delicate salad preparations.',
    price: 99,
    numericPrice: 99,
    mrp: 119,
    unit: '1 pack',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_mini_lettuce.jpg',
    tags: ['Exotic', 'Mini Greens'],
    freshnessBadge: 'Gourmet',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1 pack', price: 99 }
    ]
  },
  {
    id: 'v_cabbage',
    name: 'Cabbage',
    slug: 'cabbage',
    description: 'Firm, tightly packed green cabbage head featuring crisp leaves and long shelf life.',
    price: 59,
    numericPrice: 59,
    mrp: 69,
    unit: '1 pc',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_cabbage.jpg',
    tags: ['Indian', 'Cabbage'],
    freshnessBadge: 'Farm Direct',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1 pc', price: 59 }
    ]
  },
  {
    id: 'v_american_kale',
    name: 'American Kale',
    slug: 'american-kale',
    description: 'Robust dark curly American kale leaves packed with green phytonutrients.',
    price: 129,
    numericPrice: 129,
    mrp: 149,
    unit: '200g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_american_kale.jpg',
    tags: ['Exotic', 'Superfood', 'Kale'],
    freshnessBadge: 'Clean Greens',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '200g', price: 129 }
    ]
  },
  {
    id: 'v_kale',
    name: 'Kale',
    slug: 'kale',
    description: 'Fresh green kale leaves ideal for nutrient-dense smoothies, salads, or baked chips.',
    price: 99,
    numericPrice: 99,
    mrp: 119,
    unit: '200g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_kale.jpg',
    tags: ['Exotic', 'Kale'],
    freshnessBadge: 'Fresh Cut',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '200g', price: 99 }
    ]
  },
  {
    id: 'v_celery_root',
    name: 'Celery Root',
    slug: 'celery-root',
    description: 'Earthy celeriac (celery root) offering nutty celery notes for gourmet soups and purées.',
    price: 199,
    numericPrice: 199,
    mrp: 229,
    unit: '1 pc',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_celery_root.jpg',
    tags: ['Exotic', 'Celeriac'],
    freshnessBadge: 'Specialty',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1 pc', price: 199 }
    ]
  },
  {
    id: 'v_leek',
    name: 'Leek',
    slug: 'leek',
    description: 'Fresh leek stalks featuring long white shafts and delicate sweet onion flavor.',
    price: 149,
    numericPrice: 149,
    mrp: 169,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_leek.jpg',
    tags: ['Exotic', 'Leek'],
    freshnessBadge: 'Fresh Import',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '250g', price: 149 }
    ]
  },
  {
    id: 'v_broccoli',
    name: 'Broccoli',
    slug: 'broccoli',
    description: 'Tight green broccoli florets grown locally using clean agricultural methods.',
    price: 99,
    numericPrice: 99,
    mrp: 119,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_broccoli.jpg',
    tags: ['Indian', 'Broccoli'],
    freshnessBadge: 'Nutrient Rich',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 99 }
    ]
  },
  {
    id: 'v_cauliflower',
    name: 'Cauliflower',
    slug: 'cauliflower',
    description: 'Fresh white cauliflower curd (Gobi) with compact florets and mild taste.',
    price: 79,
    numericPrice: 79,
    mrp: 89,
    unit: '1 pc',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_cauliflower.jpg',
    tags: ['Indian', 'Cauliflower', 'Gobi'],
    freshnessBadge: 'Farm Direct',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1 pc', price: 79 }
    ]
  },
  {
    id: 'v_spring_onion',
    name: 'Spring Onion',
    slug: 'spring-onion',
    description: 'Fresh scallions with crisp white bulbs and vibrant green shoots.',
    price: 49,
    numericPrice: 49,
    mrp: 59,
    unit: '1 bunch',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_spring_onion.jpg',
    tags: ['Indian', 'Scallion'],
    freshnessBadge: 'Fresh Cut',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1 bunch', price: 49 }
    ]
  },
  {
    id: 'v_black_garlic',
    name: 'Black Garlic',
    slug: 'black-garlic',
    description: 'Aged ferment-cured black garlic cloves with sweet umami flavor and soft texture.',
    price: 199,
    numericPrice: 199,
    mrp: 229,
    unit: '100g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_black_garlic.jpg',
    tags: ['Exotic', 'Black Garlic', 'Umami'],
    freshnessBadge: 'Gourmet',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '100g', price: 199 }
    ]
  },
  {
    id: 'v_elegant_garlic',
    name: 'Elegant Garlic',
    slug: 'elegant-garlic',
    description: 'Large-cloved premium white garlic with potent pungency and essential aroma.',
    price: 149,
    numericPrice: 149,
    mrp: 169,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://placehold.co/500x500/E7E3DA/8A8170?text=Elegant%20Garlic',
    tags: ['Indian', 'Garlic'],
    freshnessBadge: 'Kitchen Essential',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '250g', price: 149 }
    ]
  },

  // PODS, NIGHTSHADES & SQUASHES (10)
  {
    id: 'v_peas',
    name: 'Peas',
    slug: 'peas',
    description: 'Sweet green garden peas (Matar) shelled fresh for cooking.',
    price: 99,
    numericPrice: 99,
    mrp: 119,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_peas.jpg',
    tags: ['Indian', 'Matar', 'Sweet Peas'],
    freshnessBadge: 'Farm Fresh',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 99 }
    ]
  },
  {
    id: 'v_beans',
    name: 'Beans',
    slug: 'beans',
    description: 'Tender green French beans harvested young for crisp snapping texture.',
    price: 89,
    numericPrice: 89,
    mrp: 99,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_beans.jpg',
    tags: ['Indian', 'French Beans'],
    freshnessBadge: 'Daily Pick',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 89 }
    ]
  },
  {
    id: 'v_cucumber',
    name: 'Cucumber',
    slug: 'cucumber',
    description: 'Cooling, crisp green cucumbers with high water content.',
    price: 59,
    numericPrice: 59,
    mrp: 69,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_cucumber.jpg',
    tags: ['Indian', 'Cucumber', 'Hydrating'],
    freshnessBadge: 'Fresh Harvest',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 59 }
    ]
  },
  {
    id: 'v_pepper',
    name: 'Pepper',
    slug: 'pepper',
    description: 'Crisp green bell pepper (Capsicum) with thick juicy flesh.',
    price: 149,
    numericPrice: 149,
    mrp: 169,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_pepper.jpg',
    tags: ['Indian', 'Capsicum'],
    freshnessBadge: 'Farm Direct',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 149 }
    ]
  },
  {
    id: 'v_squash',
    name: 'Squash',
    slug: 'squash',
    description: 'Tender summer squash featuring delicate skin and mild sweet flavor.',
    price: 99,
    numericPrice: 99,
    mrp: 119,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_squash.jpg',
    tags: ['Exotic', 'Squash'],
    freshnessBadge: 'Fresh Pick',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 99 }
    ]
  },
  {
    id: 'v_zucchini',
    name: 'Zucchini',
    slug: 'zucchini',
    description: 'Fresh green zucchini with tender flesh, ideal for sautéing or grilling.',
    price: 129,
    numericPrice: 129,
    mrp: 149,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_zucchini.jpg',
    tags: ['Exotic', 'Zucchini'],
    freshnessBadge: 'Clean Greens',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 129 }
    ]
  },
  {
    id: 'v_eggplant',
    name: 'Eggplant',
    slug: 'eggplant',
    description: 'Glossy purple eggplant (Baingan) with spongy tender interior pulp.',
    price: 69,
    numericPrice: 69,
    mrp: 79,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_eggplant.jpg',
    tags: ['Indian', 'Baingan'],
    freshnessBadge: 'Daily Pick',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 69 }
    ]
  },
  {
    id: 'v_corn',
    name: 'Corn',
    slug: 'corn',
    description: 'Sweet golden sweetcorn cobs packed with juicy corn kernels.',
    price: 79,
    numericPrice: 79,
    mrp: 89,
    unit: '2 pcs',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_corn.jpg',
    tags: ['Indian', 'Sweetcorn'],
    freshnessBadge: 'Sweet Cobs',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '2 pcs', price: 79 }
    ]
  },
  {
    id: 'v_pumpkin',
    name: 'Pumpkin',
    slug: 'pumpkin',
    description: 'Golden yellow pumpkin slice (Kaddu) with sweet dense orange flesh.',
    price: 59,
    numericPrice: 59,
    mrp: 69,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://placehold.co/500x500/E7E3DA/8A8170?text=Pumpkin',
    tags: ['Indian', 'Kaddu'],
    freshnessBadge: 'Farm Fresh',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 59 }
    ]
  },
  {
    id: 'v_mushroom',
    name: 'Mushroom',
    slug: 'mushroom',
    description: 'Fresh white button mushrooms harvested for firm texture and umami taste.',
    price: 149,
    numericPrice: 149,
    mrp: 169,
    unit: '200g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://placehold.co/500x500/E7E3DA/8A8170?text=Mushroom',
    tags: ['Indian', 'Button Mushroom'],
    freshnessBadge: 'Fresh Pack',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '200g', price: 149 }
    ]
  },

  // TOMATOES, ASPARAGUS & HERBS (11)
  {
    id: 'v_cherry_vine_tomato',
    name: 'Cherry Vine Tomato',
    slug: 'cherry-vine-tomato',
    description: 'Juicy cherry tomatoes harvested on the vine for rich sweet lycopene flavor.',
    price: 119,
    numericPrice: 119,
    mrp: 139,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_cherry_vine_tomato.jpg',
    tags: ['Exotic', 'Vine Tomato'],
    freshnessBadge: 'Vine Ripe',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '250g', price: 119 }
    ]
  },
  {
    id: 'v_yellow_cherry_tomato',
    name: 'Yellow Cherry Tomato',
    slug: 'yellow-cherry-tomato',
    description: 'Sweet yellow cherry tomatoes with low acidity and bright sunny color.',
    price: 129,
    numericPrice: 129,
    mrp: 149,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_yellow_cherry_tomato.jpg',
    tags: ['Exotic', 'Yellow Cherry'],
    freshnessBadge: 'Gourmet',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '250g', price: 129 }
    ]
  },
  {
    id: 'v_red_cherry_tomato',
    name: 'Red Cherry Tomato',
    slug: 'red-cherry-tomato',
    description: 'Plump red cherry tomatoes offering sweet burst of tomato juice.',
    price: 109,
    numericPrice: 109,
    mrp: 129,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_red_cherry_tomato.jpg',
    tags: ['Indian', 'Cherry Tomato'],
    freshnessBadge: 'Sweet Burst',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '250g', price: 109 }
    ]
  },
  {
    id: 'v_green_asparagus',
    name: 'Green Asparagus',
    slug: 'green-asparagus',
    description: 'Tender green asparagus spears featuring subtle nutty notes.',
    price: 79,
    numericPrice: 79,
    mrp: 99,
    unit: '100g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_green_asparagus.jpg',
    tags: ['Exotic', 'Asparagus'],
    freshnessBadge: 'Fresh Cut',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '100g', price: 79 }
    ]
  },
  {
    id: 'v_green_asparagus_jumbo',
    name: 'Green Asparagus Jumbo',
    slug: 'green-asparagus-jumbo',
    description: 'Thick jumbo green asparagus spears tailored for gourmet grilling.',
    price: 99,
    numericPrice: 99,
    mrp: 119,
    unit: '100g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_green_asparagus_jumbo.jpg',
    tags: ['Exotic', 'Jumbo Spear'],
    freshnessBadge: 'Gourmet',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '100g', price: 99 }
    ]
  },
  {
    id: 'v_white_asparagus',
    name: 'White Asparagus',
    slug: 'white-asparagus',
    description: 'Delicate white asparagus spears with mild nutty taste.',
    price: 149,
    numericPrice: 149,
    mrp: 169,
    unit: '100g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_white_asparagus.jpg',
    tags: ['Exotic', 'White Asparagus'],
    freshnessBadge: 'Rare Grade',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '100g', price: 149 }
    ]
  },
  {
    id: 'v_white_asparagus_peruvian',
    name: 'White Asparagus Peruvian',
    slug: 'white-asparagus-peruvian',
    description: 'Imported Peruvian white asparagus with tender texture.',
    price: 179,
    numericPrice: 179,
    mrp: 199,
    unit: '100g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_white_asparagus_peruvian.jpg',
    tags: ['Exotic', 'Peruvian'],
    freshnessBadge: 'Air Import',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '100g', price: 179 }
    ]
  },
  {
    id: 'v_asparagus_regular',
    name: 'Asparagus Regular',
    slug: 'asparagus-regular',
    description: 'Standard fresh asparagus spears for daily healthy meals.',
    price: 69,
    numericPrice: 69,
    mrp: 79,
    unit: '100g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: '/products/v_asparagus_regular.jpg',
    tags: ['Indian', 'Asparagus'],
    freshnessBadge: 'Fresh Pick',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '100g', price: 69 }
    ]
  },
  {
    id: 'v_artichoke',
    name: 'Artichoke',
    slug: 'artichoke',
    description: 'Fresh artichoke globe with tender heart and flavorful bracts.',
    price: 199,
    numericPrice: 199,
    mrp: 229,
    unit: '1 pc',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_artichoke.jpg',
    tags: ['Exotic', 'Artichoke'],
    freshnessBadge: 'Gourmet',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1 pc', price: 199 }
    ]
  },
  {
    id: 'v_garlic_chives',
    name: 'Garlic Chives',
    slug: 'garlic-chives',
    description: 'Fragrant flat garlic chives with mild garlic-onion flavor.',
    price: 99,
    numericPrice: 99,
    mrp: 119,
    unit: '1 bunch',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_garlic_chives.jpg',
    tags: ['Exotic', 'Garlic Chives'],
    freshnessBadge: 'Fresh Herb',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1 bunch', price: 99 }
    ]
  },
  {
    id: 'v_parsley',
    name: 'Parsley',
    slug: 'parsley',
    description: 'Fresh green curly parsley bunch rich in natural aromatic herbal notes.',
    price: 49,
    numericPrice: 49,
    mrp: 59,
    unit: '1 bunch',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: '/products/v_parsley.jpg',
    tags: ['Exotic', 'Parsley'],
    freshnessBadge: 'Fresh Herb',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '1 bunch', price: 49 }
    ]
  },

  // =========================================================
  // 3. MEAT AND SEAFOOD (18 PRODUCTS)
  // =========================================================
  {
    id: 'm_ch_boneless',
    name: 'Chicken Boneless Cut',
    slug: 'chicken-boneless-cut',
    description: 'Succulent 100% lean boneless chicken breast fillets for grills and stir-fries.',
    price: 349,
    numericPrice: 349,
    mrp: 389,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'boneless-cut',
    cutType: 'Boneless Cut',
    image: '/products/m_ch_boneless.jpg',
    tags: ['Lean', 'Boneless'],
    freshnessBadge: 'Farm Fresh',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 189 },
      { label: '1kg', price: 349 }
    ]
  },
  {
    id: 'm_ch_bone',
    name: 'Chicken With Bone Cut',
    slug: 'chicken-with-bone-cut',
    description: 'Juicy bone-in chicken pieces cut to absorb deep spice flavors.',
    price: 299,
    numericPrice: 299,
    mrp: 329,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'bone-cut',
    cutType: 'Bone Cut',
    image: '/products/m_ch_bone.jpg',
    tags: ['Bone-In'],
    freshnessBadge: 'Daily Fresh',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 159 },
      { label: '1kg', price: 299 }
    ]
  },
  {
    id: 'm_ch_curry',
    name: 'Farm-Fresh Chicken Curry Cut',
    slug: 'farm-fresh-chicken-curry-cut',
    description: 'Skinless bone-in chicken pieces carved for traditional Indian curry.',
    price: 329,
    numericPrice: 329,
    mrp: 359,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'curry-cut',
    cutType: 'Curry Cut',
    image: '/products/m_ch_curry.jpg',
    tags: ['Curry Cut'],
    freshnessBadge: 'Daily Fresh',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 179 },
      { label: '1kg', price: 329 }
    ]
  },
  {
    id: 'm_ch_biryani',
    name: 'Chicken Biryani Cut',
    slug: 'chicken-biryani-cut',
    description: 'Generously sized bone-in chicken chunks carved for slow-cooked biryani.',
    price: 349,
    numericPrice: 349,
    mrp: 379,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'biryani-cut',
    cutType: 'Biryani Cut',
    image: '/products/m_ch_biryani.jpg',
    tags: ['Biryani Cut'],
    freshnessBadge: 'Specialty Cut',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 189 },
      { label: '1kg', price: 349 }
    ]
  },
  {
    id: 'm_ch_kabab',
    name: 'Chicken Kebab Cut',
    slug: 'chicken-kebab-cut',
    description: 'Succulent chicken chunks sized for skewer grilling and kababs.',
    price: 399,
    numericPrice: 399,
    mrp: 439,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'kabab-cut',
    cutType: 'Kebab Cut',
    image: '/products/m_ch_kabab.jpg',
    tags: ['Kebab Cut', 'Grill Ready'],
    freshnessBadge: 'Premium Cut',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 219 },
      { label: '1kg', price: 399 }
    ]
  },
  {
    id: 'm_ch_lollipop',
    name: 'Chicken Lollipop',
    slug: 'chicken-lollipop',
    description: 'Cleanly frenched chicken wing lollipops ready for frying.',
    price: 399,
    numericPrice: 399,
    mrp: 439,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'kabab-cut',
    cutType: 'Lollipop Cut',
    image: '/products/m_ch_lollipop.jpg',
    tags: ['Lollipop'],
    freshnessBadge: 'Appetizer Cut',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 219 },
      { label: '1kg', price: 399 }
    ]
  },
  {
    id: 'm_ch_wings',
    name: 'Chicken Wings',
    slug: 'chicken-wings',
    description: 'Fresh chicken wings featuring crispy skin for roasting.',
    price: 299,
    numericPrice: 299,
    mrp: 329,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'bone-cut',
    cutType: 'Wings',
    image: '/products/m_ch_wings.jpg',
    tags: ['Wings'],
    freshnessBadge: 'Fresh Cut',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 159 },
      { label: '1kg', price: 299 }
    ]
  },
  {
    id: 'm_mu_boneless',
    name: 'Mutton Boneless Cut',
    slug: 'mutton-boneless-cut',
    description: 'Tender pasture-raised boneless mutton cubes for slow cooking.',
    price: 1299,
    numericPrice: 1299,
    mrp: 1399,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'mutton',
    subSubcategoryId: 'boneless-cut',
    cutType: 'Boneless Cut',
    image: '/products/m_mu_boneless.jpg',
    tags: ['Mutton', 'Boneless'],
    freshnessBadge: 'Pasture Raised',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 679 },
      { label: '1kg', price: 1299 }
    ]
  },
  {
    id: 'm_mu_bone',
    name: 'Mutton With Bone Cut',
    slug: 'mutton-with-bone-cut',
    description: 'Bone-in mutton cuts offering deep rich meat flavor.',
    price: 1099,
    numericPrice: 1099,
    mrp: 1199,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'mutton',
    subSubcategoryId: 'bone-cut',
    cutType: 'Bone Cut',
    image: '/products/m_mu_bone.jpg',
    tags: ['Mutton', 'Bone Cut'],
    freshnessBadge: 'Prime Grade',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 579 },
      { label: '1kg', price: 1099 }
    ]
  },
  {
    id: 'm_mu_curry',
    name: 'Mutton Curry Cut',
    slug: 'mutton-curry-cut',
    description: 'Bite-sized bone-in mutton pieces for traditional gravy dishes.',
    price: 1099,
    numericPrice: 1099,
    mrp: 1199,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'mutton',
    subSubcategoryId: 'curry-cut',
    cutType: 'Curry Cut',
    image: '/products/m_mu_curry.jpg',
    tags: ['Mutton', 'Curry Cut'],
    freshnessBadge: 'Fresh Cut',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 579 },
      { label: '1kg', price: 1099 }
    ]
  },
  {
    id: 'm_mu_biryani',
    name: 'Mutton Biryani Cut',
    slug: 'mutton-biryani-cut',
    description: 'Succulent bone-in mutton chunks tailored for dum biryani.',
    price: 1199,
    numericPrice: 1199,
    mrp: 1299,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'mutton',
    subSubcategoryId: 'biryani-cut',
    cutType: 'Biryani Cut',
    image: '/products/m_mu_biryani.jpg',
    tags: ['Mutton', 'Biryani Cut'],
    freshnessBadge: 'Gourmet Cut',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 629 },
      { label: '1kg', price: 1199 }
    ]
  },
  {
    id: 'm_mu_kabab',
    name: 'Mutton Kebab Cut',
    slug: 'mutton-kebab-cut',
    description: 'Hand-diced tender mutton chunks for seekh and galouti kebabs.',
    price: 1299,
    numericPrice: 1299,
    mrp: 1399,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'mutton',
    subSubcategoryId: 'kabab-cut',
    cutType: 'Kebab Cut',
    image: '/products/m_mu_kabab.jpg',
    tags: ['Mutton', 'Kebab Cut'],
    freshnessBadge: 'Finest Grade',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 679 },
      { label: '1kg', price: 1299 }
    ]
  },
  {
    id: 'm_fi_rohu',
    name: 'Fresh River Rohu',
    slug: 'fresh-river-rohu',
    description: 'Freshly caught sweet-water Rohu fish sliced into curry cut steaks.',
    price: 349,
    numericPrice: 349,
    mrp: 389,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'fish',
    subSubcategoryId: 'rohu',
    cutType: 'Curry Cut',
    image: '/products/m_fi_rohu.jpg',
    tags: ['Freshwater', 'Rohu'],
    freshnessBadge: 'Daily Catch',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 189 },
      { label: '1kg', price: 349 }
    ],
    fishCuts: ['Curry Cut', 'Steak Cut']
  },
  {
    id: 'm_fi_katla',
    name: 'Freshwater Katla',
    slug: 'freshwater-katla',
    description: 'Nutrient-rich freshwater Katla fish expertly sliced for cooking.',
    price: 349,
    numericPrice: 349,
    mrp: 389,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'fish',
    subSubcategoryId: 'katla',
    cutType: 'Steak Cut',
    image: '/products/m_fi_katla.jpg',
    tags: ['Freshwater', 'Katla'],
    freshnessBadge: 'Daily Catch',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 189 },
      { label: '1kg', price: 349 }
    ],
    fishCuts: ['Steak Cut', 'Curry Cut']
  },
  {
    id: 'm_fi_pomfret',
    name: 'Premium White Pomfret',
    slug: 'premium-white-pomfret',
    description: 'Whole cleaned White Pomfret wild-caught from the ocean.',
    price: 999,
    numericPrice: 999,
    mrp: 1099,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'fish',
    subSubcategoryId: 'pomfret',
    cutType: 'Whole Cleaned',
    image: '/products/m_fi_pomfret.jpg',
    tags: ['Sea Fish', 'White Pomfret'],
    freshnessBadge: 'Wild Caught',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 529 },
      { label: '1kg', price: 999 }
    ],
    fishCuts: ['Whole Cleaned', 'Sliced']
  },
  {
    id: 'm_fi_surmai',
    name: 'Surmai (King Fish)',
    slug: 'surmai-king-fish',
    description: 'Seer Fish (Surmai) cut into thick meaty steaks.',
    price: 1299,
    numericPrice: 1299,
    mrp: 1399,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'fish',
    subSubcategoryId: 'surmai',
    cutType: 'Steak Cut',
    image: '/products/m_fi_surmai.jpg',
    tags: ['Seer Fish', 'Surmai'],
    freshnessBadge: 'Wild Caught',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 679 },
      { label: '1kg', price: 1299 }
    ],
    fishCuts: ['Steak Cut', 'Boneless Fillet']
  },
  {
    id: 'm_pr_tiger',
    name: 'Jumbo Tiger Prawns',
    slug: 'jumbo-tiger-prawns',
    description: 'Large sweet Tiger Prawns, cleaned, peeled, and deveined.',
    price: 899,
    numericPrice: 899,
    mrp: 999,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'prawns',
    image: '/products/m_pr_tiger.jpg',
    tags: ['Prawns', 'Tiger Prawns'],
    freshnessBadge: 'Premium Catch',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 479 },
      { label: '1kg', price: 899 }
    ],
    cleaningOptions: ['Deveined', 'Tail-On']
  },
  {
    id: 'm_pr_white',
    name: 'Medium White Prawns',
    slug: 'medium-white-prawns',
    description: 'Tender fresh white prawns, peeled and deveined.',
    price: 599,
    numericPrice: 599,
    mrp: 649,
    unit: '1kg',
    categoryId: 'meat',
    subcategoryId: 'prawns',
    image: '/products/m_pr_white.jpg',
    tags: ['Prawns', 'White Prawns'],
    freshnessBadge: 'Super Fresh',
    deliveryEstimate: '90 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '500g', price: 319 },
      { label: '1kg', price: 599 }
    ],
    cleaningOptions: ['Deveined', 'Whole Cleaned']
  },

  // =========================================================
  // 4. SMOOTHIES (4 PRODUCTS)
  // =========================================================
  {
    id: 's_avocado',
    name: 'Avocado Classic',
    slug: 'avocado-classic',
    description: 'Creamy blend of ripe Hass avocado, fresh spinach, and almond milk.',
    price: 149,
    numericPrice: 149,
    mrp: 169,
    unit: '300 ml',
    categoryId: 'smoothies',
    image: '/products/s_avocado.jpg',
    tags: ['Cold Pressed', 'Creamy'],
    freshnessBadge: 'Fresh Blended',
    deliveryEstimate: '30 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '300 ml', price: 149 },
      { label: '500 ml', price: 229 }
    ]
  },
  {
    id: 's_blueberry',
    name: 'Blueberry Smoothie',
    slug: 'blueberry-smoothie',
    description: 'Blend of handpicked blueberries, Greek yogurt, and chia seeds.',
    price: 179,
    numericPrice: 179,
    mrp: 199,
    unit: '300 ml',
    categoryId: 'smoothies',
    image: '/products/s_blueberry.jpg',
    tags: ['Antioxidant', 'Superfood'],
    freshnessBadge: 'Made To Order',
    deliveryEstimate: '30 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '300 ml', price: 179 },
      { label: '500 ml', price: 269 }
    ]
  },
  {
    id: 's_raspberry',
    name: 'Raspberry Smoothie',
    slug: 'raspberry-smoothie',
    description: 'Tart-sweet smoothie made with red raspberries and oat cream.',
    price: 179,
    numericPrice: 179,
    mrp: 199,
    unit: '300 ml',
    categoryId: 'smoothies',
    image: '/products/s_raspberry.jpg',
    tags: ['Vegan', 'Refreshing'],
    freshnessBadge: 'Made To Order',
    deliveryEstimate: '30 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '300 ml', price: 179 },
      { label: '500 ml', price: 269 }
    ]
  },
  {
    id: 's_red_grape',
    name: 'Red Grape Smoothie',
    slug: 'red-grape-smoothie',
    description: 'Puree of seedless red grapes, chia seeds, and fresh apple juice.',
    price: 149,
    numericPrice: 149,
    mrp: 169,
    unit: '300 ml',
    categoryId: 'smoothies',
    image: '/products/s_red_grape.jpg',
    tags: ['Hydrating', 'Red Grape'],
    freshnessBadge: 'Fresh Press',
    deliveryEstimate: '60 mins',
    stockStatus: 'in_stock',
    weights: [
      { label: '300 ml', price: 149 },
      { label: '500 ml', price: 229 }
    ]
  }
];
