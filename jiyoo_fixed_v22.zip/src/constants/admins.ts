export const ADMIN_EMAILS = [
  'yoyokishwar@gmail.com',
  'jiyooshams@gmail.com',
  'shamsjiyoo@gmail.com'
];
