import { useState, useEffect } from 'react';
import { collection, onSnapshot, query, orderBy, doc, updateDoc , limit } from 'firebase/firestore';
import { db } from '../../../services/firebase';
import { Order } from '../../../types';
import { useSettings } from '../../../contexts/SettingsContext';
import { CreditCard, ExternalLink, Search, RefreshCw, DollarSign, QrCode } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '../../core/contexts/ToastContext';

export function PaymentsTab() {
  const { showToast } = useToast();
  const { settings, updateSettings } = useSettings();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [methodFilter, setMethodFilter] = useState<string>('all');
  
  // Local settings edit
  const [upiId, setUpiId] = useState(settings.upiId || '9739391891@ybl');
  const [upiId2, setUpiId2] = useState(settings.upiId2 || '9739391891@paytm');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    setUpiId(settings.upiId || '9739391891@ybl');
    setUpiId2(settings.upiId2 || '9739391891@paytm');
  }, [settings]);

  useEffect(() => {
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'), limit(100));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const loaded: Order[] = [];
        snap.forEach(d => {
          loaded.push({ id: d.id, ...d.data() } as Order);
        });
        setOrders(loaded);
        setLoading(false);
      },
      (err) => {
        console.error('Error listening to orders in PaymentsTab:', err);
        setLoading(false);
      }
    );
    return () => unsub();
  }, []);

  const handleSaveKeys = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await updateSettings({
        upiId,
        upiId2,
      });
      showToast('Payment settings updated successfully!', 'success');
    } catch (err: any) {
      if (err.message && err.message.includes('offline')) {
        showToast('Settings saved locally! Your Firebase Database is not created yet — go to Firebase Console and create it in Firestore.', 'error');
      } else {
        showToast('Error updating payment settings to Cloud: ' + err.message, 'error');
      }
    } finally {
      setIsSaving(false);
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { status: newStatus });
    } catch (err) {
      console.error('Failed to update status:', err);
      showToast('Could not update status', 'error');
    }
  };

  // Calculations
  const validStatuses = ['completed', 'delivered', 'paid'];
  const paidOrders = orders.filter(o => validStatuses.includes(o.status || ''));

  const razorpayOrders = paidOrders.filter(o => 
    o.paymentMethod?.toLowerCase().includes('razorpay') || o.paymentMethod?.toLowerCase().includes('online')
  );
  const upiOrders = paidOrders.filter(o => 
    o.paymentMethod?.toLowerCase().includes('upi') || o.paymentMethod?.toLowerCase().includes('qr')
  );
  const codOrders = paidOrders.filter(o => 
    o.paymentMethod?.toLowerCase().includes('cod') || o.paymentMethod?.toLowerCase().includes('cash')
  );

  const razorpayTotal = razorpayOrders.reduce((sum, o) => sum + (o.amount || 0), 0);
  const upiTotal = upiOrders.reduce((sum, o) => sum + (o.amount || 0), 0);
  const codTotal = codOrders.reduce((sum, o) => sum + (o.amount || 0), 0);
  const grandTotal = paidOrders.reduce((sum, o) => sum + (o.amount || 0), 0);

  const filteredOrders = orders.filter(o => {
    const matchesSearch = 
      o.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.shippingDetails?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (o as any).utrNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (o as any).razorpayPaymentId?.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (!matchesSearch) return false;
    if (methodFilter === 'razorpay') return o.paymentMethod?.toLowerCase().includes('razorpay') || o.paymentMethod?.toLowerCase().includes('online');
    if (methodFilter === 'upi') return o.paymentMethod?.toLowerCase().includes('upi') || o.paymentMethod?.toLowerCase().includes('qr');
    if (methodFilter === 'cod') return o.paymentMethod?.toLowerCase().includes('cod') || o.paymentMethod?.toLowerCase().includes('cash');
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-brand-black flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-emerald-600" />
            Razorpay & Payment Dashboard
          </h2>
          <p className="text-brand-gray-500">Real-time payment gateway monitoring, transaction ledger, and gateway keys.</p>
        </div>
        <a 
          href="https://dashboard.razorpay.com" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors shadow-sm"
        >
          <span>Razorpay Live Dashboard</span>
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-brand-gray-200 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs font-semibold text-brand-gray-500 uppercase tracking-wider">Razorpay Online</span>
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-bold text-brand-black">₹{razorpayTotal.toLocaleString('en-IN')}</div>
            <div className="text-xs text-brand-gray-500 mt-1">{razorpayOrders.length} transactions captured</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-brand-gray-200 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs font-semibold text-brand-gray-500 uppercase tracking-wider">UPI QR Payments</span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
              <QrCode className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-bold text-brand-black">₹{upiTotal.toLocaleString('en-IN')}</div>
            <div className="text-xs text-brand-gray-500 mt-1">{upiOrders.length} instant QR orders</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-brand-gray-200 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs font-semibold text-brand-gray-500 uppercase tracking-wider">Cash on Delivery</span>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-bold text-brand-black">₹{codTotal.toLocaleString('en-IN')}</div>
            <div className="text-xs text-brand-gray-500 mt-1">{codOrders.length} COD orders</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-brand-gray-200 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-xs font-semibold text-brand-gray-500 uppercase tracking-wider">Total Sales</span>
            <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
              <ArrowUpRight className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-bold text-brand-black">₹{grandTotal.toLocaleString('en-IN')}</div>
            <div className="text-xs text-brand-gray-500 mt-1">{orders.length} total orders across store</div>
          </div>
        </div>
      </div>

            {/* Payment Configuration Setup Card */}
      <div className="bg-white p-6 rounded-xl border border-brand-gray-200 shadow-sm">
        <div className="flex items-center justify-between pb-4 border-b border-brand-gray-100 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-brand-black">UPI & Payment Configuration</h3>
              <p className="text-xs text-brand-gray-500">Configure your Store UPI IDs. (Razorpay keys are configured in server environment).</p>
            </div>
          </div>
        </div>
        
        <form onSubmit={handleSaveKeys} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-brand-gray-700 mb-1 flex items-center gap-1">
                <QrCode className="w-3.5 h-3.5 text-brand-gray-400" />
                Primary Store UPI VPA (QR 1)
              </label>
              <input 
                type="text" 
                value={upiId} 
                onChange={e => setUpiId(e.target.value)}
                className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600 font-mono"
                placeholder="9739391891@ybl"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-brand-gray-700 mb-1 flex items-center gap-1">
                <QrCode className="w-3.5 h-3.5 text-brand-gray-400" />
                Secondary Store UPI VPA (QR 2)
              </label>
              <input 
                type="text" 
                value={upiId2} 
                onChange={e => setUpiId2(e.target.value)}
                className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600 font-mono"
                placeholder="9739391891@paytm"
              />
            </div>
          </div>
          
          <div className="flex items-end justify-end pt-2">
            <button 
              type="submit" 
              disabled={isSaving}
              className="px-6 py-2.5 bg-brand-black text-white rounded-lg text-sm font-medium hover:bg-brand-gray-900 transition-colors whitespace-nowrap shadow-sm"
            >
              {isSaving ? 'Saving...' : 'Save Payment Keys'}
            </button>
          </div>
        </form>
      </div>

      {/* Transactions Ledger */}
      <div className="bg-white rounded-xl border border-brand-gray-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-brand-gray-200 flex flex-col md:flex-row gap-4 justify-between items-stretch md:items-center bg-brand-gray-50/50">
          <div className="flex items-center gap-2 flex-1 max-w-md relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-gray-400" />
            <input 
              type="text"
              placeholder="Search by Order ID, Customer, UTR, or Payment ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-white border border-brand-gray-200 rounded-lg outline-none focus:border-emerald-600 text-sm"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-brand-gray-500">Filter:</span>
            <button 
              onClick={() => setMethodFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${methodFilter === 'all' ? 'bg-brand-black text-white' : 'bg-white text-brand-gray-600 border border-brand-gray-200'}`}
            >
              All ({orders.length})
            </button>
            <button 
              onClick={() => setMethodFilter('razorpay')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${methodFilter === 'razorpay' ? 'bg-blue-600 text-white' : 'bg-white text-brand-gray-600 border border-brand-gray-200'}`}
            >
              Razorpay ({razorpayOrders.length})
            </button>
            <button 
              onClick={() => setMethodFilter('upi')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${methodFilter === 'upi' ? 'bg-emerald-600 text-white' : 'bg-white text-brand-gray-600 border border-brand-gray-200'}`}
            >
              UPI QR ({upiOrders.length})
            </button>
            <button 
              onClick={() => setMethodFilter('cod')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${methodFilter === 'cod' ? 'bg-amber-600 text-white' : 'bg-white text-brand-gray-600 border border-brand-gray-200'}`}
            >
              COD ({codOrders.length})
            </button>
          </div>
        </div>

        {loading ? (
          <div className="py-12 text-center text-brand-gray-500 flex items-center justify-center gap-2">
            <RefreshCw className="w-5 h-5 animate-spin text-emerald-600" />
            Loading real-time transactions...
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="py-12 text-center text-brand-gray-500">
            No transactions found matching criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-brand-gray-500 uppercase bg-brand-gray-50 border-b border-brand-gray-200">
                <tr>
                  <th className="px-4 py-3">Order ID / Date</th>
                  <th className="px-4 py-3">Customer</th>
                  <th className="px-4 py-3">Payment Method</th>
                  <th className="px-4 py-3">Reference / UTR</th>
                  <th className="px-4 py-3">Amount</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-gray-100">
                {filteredOrders.map(o => {
                  const isUpi = o.paymentMethod?.toLowerCase().includes('upi') || o.paymentMethod?.toLowerCase().includes('qr');
                  const isRzp = o.paymentMethod?.toLowerCase().includes('razorpay') || o.paymentMethod?.toLowerCase().includes('online');
                  const utr = (o as any).utrNumber || (o as any).razorpayPaymentId || '-';

                  return (
                    <tr key={o.id} className="hover:bg-brand-gray-50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="font-semibold text-brand-black">{o.id}</div>
                        <div className="text-xs text-brand-gray-400">
                          {(o.createdAt as any)?.seconds ? format(new Date((o.createdAt as any).seconds * 1000), 'MMM d, yyyy HH:mm') : 'Recent'}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-brand-black">{o.shippingDetails?.name || 'Guest User'}</div>
                        <div className="text-xs text-brand-gray-500 font-mono">{o.shippingDetails?.phone}</div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold inline-flex items-center gap-1 ${
                          isRzp ? 'bg-blue-100 text-blue-800' : isUpi ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {isRzp && <CreditCard className="w-3 h-3" />}
                          {isUpi && <QrCode className="w-3 h-3" />}
                          {o.paymentMethod || 'Online Payment'}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-brand-black">
                        {utr}
                      </td>
                      <td className="px-4 py-3 font-bold text-brand-black">
                        ₹{o.amount}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                          o.status === 'completed' || o.status === 'delivered' || o.status === 'paid'
                            ? 'bg-green-100 text-green-700'
                            : o.status === 'processing' || o.status === 'pending'
                            ? 'bg-blue-100 text-blue-700'
                            : 'bg-amber-100 text-amber-700'
                        }`}>
                          {o.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {o.status !== 'completed' && o.status !== 'delivered' && (
                            <button
                              onClick={() => updateOrderStatus(o.id, 'completed')}
                              className="px-2.5 py-1 bg-emerald-600 text-white rounded text-xs font-medium hover:bg-emerald-700 transition-colors"
                              title="Confirm Payment & Complete Order"
                            >
                              Verify
                            </button>
                          )}
                          <select 
                            value={o.status}
                            onChange={(e) => updateOrderStatus(o.id, e.target.value)}
                            className="bg-brand-gray-50 border border-brand-gray-200 text-brand-black text-xs rounded p-1 outline-none focus:border-emerald-600"
                          >
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="completed">Completed</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
