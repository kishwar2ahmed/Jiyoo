import { useState } from 'react';
import { CreditCard, CheckCircle2, Download, Zap, ShieldCheck, Plus, Building, FileText } from 'lucide-react';
import { logAuditEvent } from '../../../services/auditService';
import { useToast } from '../../core/contexts/ToastContext';

export function BillingTab() {
  const { showToast } = useToast();
  const [seats, setSeats] = useState(5);
  const [usedSeats] = useState(3);
  const [selectedPlan, setSelectedPlan] = useState<'ENTERPRISE' | 'PRO'>('ENTERPRISE');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const invoices = [
    { id: 'INV-2026-08', date: 'Aug 01, 2026', amount: '₹14,999', status: 'PAID', plan: 'Enterprise Organization (Annual)' },
    { id: 'INV-2026-07', date: 'Jul 01, 2026', amount: '₹14,999', status: 'PAID', plan: 'Enterprise Organization (Annual)' },
    { id: 'INV-2026-06', date: 'Jun 01, 2026', amount: '₹14,999', status: 'PAID', plan: 'Enterprise Organization (Annual)' },
  ];

  const handleDownloadInvoice = (id: string) => {
    setDownloadingId(id);
    logAuditEvent('DOWNLOAD_INVOICE', 'BILLING', 'Admin', `Downloaded invoice receipt for ${id}`);
    setTimeout(() => {
      setDownloadingId(null);
      showToast(`Invoice ${id} downloaded as PDF receipt.`, "success");
    }, 600);
  };

  const handleAddSeats = () => {
    const additional = prompt("Enter additional seat count to add to your plan:", "2");
    if (additional && !isNaN(Number(additional))) {
      const count = Number(additional);
      setSeats(prev => prev + count);
      logAuditEvent('ADD_BILLING_SEATS', 'BILLING', 'Admin', `Added ${count} seat(s). New seat total: ${seats + count}`);
      showToast(`Added ${count} seats successfully! Updated total: ${seats + count} seats.`, "success");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-brand-black flex items-center gap-2">
          <CreditCard className="w-6 h-6 text-emerald-600" />
          Billing & Plan Management
        </h2>
        <p className="text-brand-gray-500">Manage account subscription, admin seat allocation, and download invoices.</p>
      </div>

      {/* Plan Summary Banner */}
      <div className="bg-gradient-to-br from-brand-black via-[#1F2937] to-[#111827] text-white p-6 rounded-2xl shadow-lg relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] uppercase font-mono font-bold tracking-widest px-2.5 py-1 rounded-full">
                Active Subscription
              </span>
              <span className="text-xs text-stone-400 font-mono">B2B ID: ORG-JIYOO-993</span>
            </div>
            <h3 className="text-2xl font-serif font-bold text-white flex items-center gap-3">
              Enterprise Growth Tier
              <ShieldCheck className="w-5 h-5 text-emerald-400 inline" />
            </h3>
            <p className="text-sm text-stone-300 max-w-xl">
              Includes unlimited store inventory, dedicated cold-chain telemetry logs, multi-admin permissions, and 24/7 dedicated account manager support.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/15 min-w-[220px] space-y-3">
            <div className="text-xs text-stone-300 uppercase tracking-wider font-mono">Current Plan Cost</div>
            <div className="text-3xl font-bold text-white font-mono">₹14,999 <span className="text-xs text-stone-400 font-normal">/ month</span></div>
            <div className="text-xs text-emerald-400 flex items-center gap-1 font-mono">
              <CheckCircle2 className="w-3.5 h-3.5" /> Next renewal: Sep 01, 2026
            </div>
          </div>
        </div>
      </div>

      {/* Seat Counts & Organization Allocation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-brand-gray-200 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-brand-black flex items-center gap-2">
              <Building className="w-5 h-5 text-emerald-600" />
              Seat Count Allocation
            </h4>
            <button 
              onClick={handleAddSeats}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Add Seats
            </button>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm font-medium">
              <span className="text-brand-gray-600">Admin Seats Used</span>
              <span className="text-brand-black font-bold font-mono">{usedSeats} / {seats} Seats</span>
            </div>
            <div className="w-full bg-brand-gray-100 rounded-full h-2.5 overflow-hidden">
              <div 
                className="bg-emerald-600 h-2.5 rounded-full transition-all duration-500" 
                style={{ width: `${(usedSeats / seats) * 100}%` }}
              />
            </div>
            <p className="text-xs text-brand-gray-400">
              {seats - usedSeats} seats available for new team administrators or store managers.
            </p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-brand-gray-200 space-y-4">
          <h4 className="font-bold text-brand-black flex items-center gap-2">
            <Zap className="w-5 h-5 text-emerald-600" />
            Included Enterprise Features
          </h4>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-brand-gray-700">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              Role-Based Granular Access
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              Immutable Audit Logs
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              Real-time Firestore Sync
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              CSV & PDF Exports
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              Custom Domain & SSO Ready
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              Dedicated WhatsApp Gateway
            </li>
          </ul>
        </div>
      </div>

      {/* Invoices History Table */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-brand-gray-200 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-bold text-brand-black flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-600" />
            Billing & Invoices History
          </h4>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-brand-gray-500 uppercase bg-brand-gray-50">
              <tr>
                <th className="px-4 py-3 rounded-tl-lg">Invoice ID</th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Plan Details</th>
                <th className="px-4 py-3">Amount</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 rounded-tr-lg text-right">Receipt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-brand-gray-100">
              {invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-brand-gray-50 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs font-bold text-brand-black">{inv.id}</td>
                  <td className="px-4 py-3 text-brand-gray-600 text-xs">{inv.date}</td>
                  <td className="px-4 py-3 text-brand-gray-700 text-xs font-medium">{inv.plan}</td>
                  <td className="px-4 py-3 font-mono font-bold text-brand-black text-xs">{inv.amount}</td>
                  <td className="px-4 py-3">
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold tracking-wider px-2.5 py-0.5 rounded-full uppercase">
                      {inv.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button 
                      onClick={() => handleDownloadInvoice(inv.id)}
                      disabled={downloadingId === inv.id}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 hover:text-emerald-800 hover:underline"
                    >
                      <Download className="w-3.5 h-3.5" />
                      {downloadingId === inv.id ? "Generating PDF..." : "Download"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
