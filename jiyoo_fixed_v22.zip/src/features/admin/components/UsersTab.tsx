import { useState, useEffect } from 'react';
import { collection, doc, updateDoc, deleteDoc, setDoc, onSnapshot, query, limit } from 'firebase/firestore';
import { db } from '../../../services/firebase';
import { AuthUser } from '../../../types';
import { Search, UserPlus, Trash2, X, Check } from 'lucide-react';
import { logAuditEvent } from '../../../services/auditService';
import { useToast } from '../../core/contexts/ToastContext';
import { useConfirm } from '../../core/contexts/ConfirmContext';

export function UsersTab() {
  const { showToast } = useToast();
  const confirm = useConfirm();
  const [users, setUsers] = useState<AuthUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  // Invite Modal State
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteName, setInviteName] = useState('');
  const [inviteRole, setInviteRole] = useState<'user' | 'admin'>('user');
  const [isSendingInvite, setIsSendingInvite] = useState(false);
  const [inviteSuccess, setInviteSuccess] = useState('');

  useEffect(() => {
    const unsub = onSnapshot(
      query(collection(db, 'users'), limit(100)),
      (snap) => {
        const loaded: AuthUser[] = [];
        snap.forEach(docSnap => {
          loaded.push({ id: docSnap.id, ...docSnap.data() } as AuthUser);
        });
        setUsers(loaded);
        setLoading(false);
      },
      (err) => {
        console.error('Error listening to users:', err);
        setLoading(false);
      }
    );
    return () => unsub();
  }, []);

  const updateRole = async (id: string, newRole: string) => {
    try {
      await updateDoc(doc(db, 'users', id), { role: newRole });
      setUsers(prev => prev.map(u => u.id === id ? { ...u, role: newRole } : u));
      logAuditEvent('CHANGE_USER_ROLE', 'USERS', 'Admin', `Changed user ${id} role to ${newRole}`);
    } catch (err) {
      console.error("Error updating role", err);
      showToast("Failed to update role", "error");
    }
  };

  const removeUser = async (userToRemove: AuthUser) => {
    if (!(await confirm({
      title: "Remove user?",
      message: `Are you sure you want to remove user ${userToRemove.name || userToRemove.email}? This action cannot be undone.`,
    }))) {
      return;
    }
    try {
      await deleteDoc(doc(db, 'users', userToRemove.id));
      setUsers(prev => prev.filter(u => u.id !== userToRemove.id));
      logAuditEvent('REMOVE_USER', 'USERS', 'Admin', `Removed member ${userToRemove.email} (${userToRemove.id})`);
      showToast(`User ${userToRemove.name || userToRemove.email} removed successfully.`, "success");
    } catch (err) {
      console.error("Error deleting user", err);
      showToast("Failed to remove user: " + (err as any).message, "error");
    }
  };

  const handleSendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail) return;

    setIsSendingInvite(true);
    setInviteSuccess('');

    try {
      const newUserId = 'invited_' + Date.now();
      await setDoc(doc(db, 'users', newUserId), {
        name: inviteName || inviteEmail.split('@')[0],
        email: inviteEmail.toLowerCase(),
        role: inviteRole,
        invitedAt: new Date().toISOString(),
        status: 'PENDING_ACCEPTANCE'
      });

      logAuditEvent('INVITE_MEMBER', 'USERS', 'Admin', `Invited ${inviteEmail} as ${inviteRole}`);
      setInviteSuccess(`Invitation link generated and dispatched to ${inviteEmail}!`);
      
      setTimeout(() => {
        setShowInviteModal(false);
        setInviteEmail('');
        setInviteName('');
        setInviteRole('user');
        setInviteSuccess('');
      }, 1500);

    } catch (err: any) {
      console.error("Error sending invite", err);
      showToast("Failed to send invitation: " + err.message, "error");
    } finally {
      setIsSendingInvite(false);
    }
  };

  const filteredUsers = users.filter(u => 
    u.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-brand-black">User Management</h2>
          <p className="text-brand-gray-500">View team members, manage permissions, invite users, or revoke access.</p>
        </div>

        <button 
          onClick={() => setShowInviteModal(true)}
          className="bg-brand-black hover:bg-brand-gray-900 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2 self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4 text-emerald-400" />
          Invite Member
        </button>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-brand-gray-200 space-y-4">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-gray-400" />
          <input 
            type="text"
            placeholder="Search users by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-brand-gray-50 border border-brand-gray-200 rounded-lg outline-none focus:border-emerald-600 text-sm"
          />
        </div>

        {loading ? (
          <div className="py-12 text-center text-brand-gray-500">Loading user accounts...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-brand-gray-500 uppercase bg-brand-gray-50">
                <tr>
                  <th className="px-4 py-3 rounded-tl-lg">User</th>
                  <th className="px-4 py-3">Email</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 rounded-tr-lg text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-gray-100">
                {filteredUsers.map(u => (
                  <tr key={u.id} className="hover:bg-brand-gray-50/80 transition-colors">
                    <td className="px-4 py-3 flex items-center gap-3">
                      {u.picture ? (
                        <img src={u.picture} alt={u.name} className="w-8 h-8 rounded-full border border-brand-gray-200 shrink-0" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-brand-black text-white flex items-center justify-center text-xs font-bold shrink-0">
                          {u.name?.slice(0, 2).toUpperCase() || 'U'}
                        </div>
                      )}
                      <div>
                        <span className="font-medium text-brand-black block">{u.name || 'Unnamed User'}</span>
                        <span className="text-[10px] text-brand-gray-400 font-mono">ID: {u.id.slice(0, 10)}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-brand-gray-600 font-mono text-xs">{u.email}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        u.role === 'admin' 
                          ? 'bg-purple-100 text-purple-700 border border-purple-200' 
                          : 'bg-brand-gray-100 text-brand-gray-700'
                      }`}>
                        {u.role || 'user'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full uppercase">
                        <Check className="w-3 h-3 text-emerald-600" /> Active
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <select 
                          value={u.role || 'user'}
                          onChange={async (e) => {
                            const newRole = e.target.value;
                            if (newRole === 'admin') {
                              if (await confirm({ title: "Promote to admin?", message: `Promote ${u.name || u.email} to Admin?`, danger: false, confirmLabel: "Promote" })) {
                                updateRole(u.id, newRole);
                              }
                            } else {
                              updateRole(u.id, newRole);
                            }
                          }}
                          className="bg-brand-gray-50 border border-brand-gray-200 text-brand-black text-xs rounded-lg focus:ring-emerald-600 focus:border-emerald-600 p-1.5"
                        >
                          <option value="user">User</option>
                          <option value="admin">Admin</option>
                        </select>

                        <button 
                          onClick={() => removeUser(u)}
                          title="Remove Member"
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Invite Member Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 z-[120] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-brand-gray-200 space-y-4 relative animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-brand-gray-100">
              <h3 className="text-lg font-bold text-brand-black flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-600" />
                Invite Team Member
              </h3>
              <button onClick={() => setShowInviteModal(false)} className="p-1 hover:bg-brand-gray-100 rounded-full">
                <X className="w-5 h-5 text-brand-gray-500" />
              </button>
            </div>

            {inviteSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-medium flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                {inviteSuccess}
              </div>
            )}

            <form onSubmit={handleSendInvite} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-brand-gray-700 uppercase tracking-wider mb-1">
                  Email Address *
                </label>
                <input 
                  type="email"
                  required
                  placeholder="colleague@jiyoo.com"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-brand-gray-700 uppercase tracking-wider mb-1">
                  Member Name (Optional)
                </label>
                <input 
                  type="text"
                  placeholder="e.g. Alex Rivera"
                  value={inviteName}
                  onChange={(e) => setInviteName(e.target.value)}
                  className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-brand-gray-700 uppercase tracking-wider mb-1">
                  Access Role
                </label>
                <select 
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value as 'user' | 'admin')}
                  className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
                >
                  <option value="user">Customer / Team User</option>
                  <option value="admin">Administrator (Full Access)</option>
                </select>
              </div>

              <div className="pt-3 border-t border-brand-gray-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowInviteModal(false)}
                  className="px-4 py-2 text-sm text-brand-gray-600 hover:bg-brand-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSendingInvite}
                  className="bg-brand-black hover:bg-brand-gray-900 text-white px-5 py-2 rounded-lg text-sm font-medium flex items-center gap-2"
                >
                  {isSendingInvite ? 'Sending Invite...' : 'Send Invitation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
