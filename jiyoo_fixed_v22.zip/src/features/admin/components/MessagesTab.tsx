import { useState, useEffect } from 'react';
import { collection, onSnapshot, query, orderBy, doc, deleteDoc } from 'firebase/firestore';
import { db } from '../../../services/firebase';
import { MessageSquare, Search, Trash2, Mail, Phone, User } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '../../core/contexts/ToastContext';
import { useConfirm } from '../../core/contexts/ConfirmContext';

export function MessagesTab() {
  const { showToast } = useToast();
  const confirm = useConfirm();
  const [messages, setMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'messages'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const loaded: any[] = [];
        snap.forEach(d => {
          loaded.push({ id: d.id, ...d.data() });
        });
        setMessages(loaded);
        setLoading(false);
      },
      (err) => {
        console.error('Error listening to messages:', err);
        setLoading(false);
      }
    );
    return () => unsub();
  }, []);

  const handleDelete = async (id: string) => {
    if (!(await confirm({ title: "Delete message?", message: "Are you sure you want to delete this message?" }))) return;
    try {
      await deleteDoc(doc(db, 'messages', id));
    } catch (err) {
      showToast('Error deleting message', 'error');
    }
  };

  const filtered = messages.filter(m => 
    m.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.message?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-brand-black">Messages & Support</h2>
          <p className="text-brand-gray-500">Manage customer inquiries and contact form submissions live.</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-brand-gray-200 overflow-hidden">
        <div className="p-4 border-b border-brand-gray-200 flex justify-between items-center">
          <div className="relative max-w-md w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-brand-gray-400" />
            <input 
              type="text" 
              placeholder="Search messages by name, email, or content..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-2 bg-brand-gray-50 border border-brand-gray-200 rounded-xl focus:outline-none focus:border-emerald-600 text-sm w-full"
            />
          </div>
        </div>
        
        {loading ? (
          <div className="p-8 text-center text-brand-gray-500">Loading messages...</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-brand-gray-500">
            <MessageSquare className="w-12 h-12 mx-auto text-brand-gray-300 mb-4" />
            <p className="font-medium text-brand-black">Inbox is empty</p>
            <p className="text-sm">You have no new messages from customers.</p>
          </div>
        ) : (
          <div className="divide-y divide-brand-gray-100">
            {filtered.map(m => (
              <div key={m.id} className="p-4 sm:p-6 flex flex-col sm:flex-row justify-between items-start gap-4 hover:bg-brand-gray-50/50 transition-colors">
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="font-semibold text-brand-black flex items-center gap-1">
                      <User className="w-3.5 h-3.5 text-brand-gray-400" />
                      {m.name || 'Anonymous Customer'}
                    </span>
                    {m.email && (
                      <a href={`mailto:${m.email}`} className="text-xs text-emerald-600 hover:underline flex items-center gap-1">
                        <Mail className="w-3 h-3" />
                        {m.email}
                      </a>
                    )}
                    {m.phone && (
                      <span className="text-xs text-brand-gray-500 flex items-center gap-1 font-mono">
                        <Phone className="w-3 h-3" />
                        {m.phone}
                      </span>
                    )}
                    <span className="text-xs text-brand-gray-400 ml-auto">
                      {m.createdAt?.seconds ? format(new Date(m.createdAt.seconds * 1000), 'MMM d, yyyy HH:mm') : 'Recent'}
                    </span>
                  </div>
                  <p className="text-sm text-brand-gray-700 bg-brand-gray-50 p-3 rounded-lg border border-brand-gray-100">
                    {m.message || m.content}
                  </p>
                </div>
                <button 
                  onClick={() => handleDelete(m.id)}
                  className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors"
                  title="Delete Message"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
