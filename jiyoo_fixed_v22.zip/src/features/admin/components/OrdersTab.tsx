import { useState, useEffect } from 'react';
import { collection, doc, updateDoc, orderBy, query, onSnapshot, limit } from 'firebase/firestore';
import { db } from '../../../services/firebase';
import { getAuth } from 'firebase/auth';
import { Order } from '../../../types';
import { Search, Eye, X, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '../../core/contexts/ToastContext';

// A 15s timeout so a hung Firestore connection (e.g. in restrictive mobile
// WebViews/networks) rejects with a clear error instead of leaving the
// caller's loading state — and the UI's Save/Update button — stuck forever.
function withTimeout<T>(promise: Promise<T>, ms = 15000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error('Request timed out — check your internet connection and try again.')), ms)
    ),
  ]);
}

export function OrdersTab() {
  const { showToast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    let unsub: (() => void) | null = null;
    const timer = setTimeout(() => {
      setLoading(false);
    }, 800);

    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'), limit(100));
    unsub = onSnapshot(
      q,
      (snap) => {
        const loaded: Order[] = [];
        snap.forEach(docSnap => {
          loaded.push({ id: docSnap.id, ...docSnap.data() } as Order);
        });
        setOrders(loaded);
        setLoading(false);
      },
      (err) => {
        console.warn('Error listening to ordered snapshot, trying basic query:', err);
        // Fallback query without orderBy in case index is missing
        const fallbackQ = query(collection(db, 'orders'), limit(100));
        unsub = onSnapshot(fallbackQ, (snap) => {
          const loaded: Order[] = [];
          snap.forEach(docSnap => {
            loaded.push({ id: docSnap.id, ...docSnap.data() } as Order);
          });
          setOrders(loaded);
          setLoading(false);
        }, () => setLoading(false));
      }
    );
    return () => {
      clearTimeout(timer);
      if (unsub) unsub();
    };
  }, []);

  const updateOrderStatus = async (orderId: string, newOrderStatus: string) => {
    try {
      await withTimeout(
        updateDoc(doc(db, 'orders', orderId), { 
          orderStatus: newOrderStatus, 
          status: newOrderStatus,
          updatedAt: new Date().toISOString()
        })
      );
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, orderStatus: newOrderStatus, status: newOrderStatus } : o));
      
      const order = orders.find(o => o.id === orderId);
      if (order && order.userId && order.userId !== 'guest') {
        const token = await getAuth().currentUser?.getIdToken();
        await fetch('/api/send-notification', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': token ? `Bearer ${token}` : ''
          },
          body: JSON.stringify({
            userId: order.userId,
            title: 'Order Status Updated',
            body: `Your order ${orderId} is now ${newOrderStatus}.`,
            data: { orderId }
          })
        }).catch(() => {});
      }
    } catch (err) {
      console.error("Error updating order status", err);
      showToast("Failed to update order status", "error");
    }
  };

  const updatePaymentStatus = async (orderId: string, newPaymentStatus: string) => {
    try {
      await withTimeout(
        updateDoc(doc(db, 'orders', orderId), { 
          paymentStatus: newPaymentStatus,
          updatedAt: new Date().toISOString()
        })
      );
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, paymentStatus: newPaymentStatus } : o));
    } catch (err) {
      console.error("Error updating payment status", err);
      showToast("Failed to update payment status", "error");
    }
  };

  const getOrderStatusColor = (status?: string) => {
    const s = (status || '').toLowerCase();
    switch(s) {
      case 'delivered':
      case 'completed': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'confirmed':
      case 'packed':
      case 'dispatched':
      case 'out_for_delivery': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'cancelled': return 'bg-rose-100 text-rose-800 border-rose-200';
      default: return 'bg-amber-100 text-amber-800 border-amber-200';
    }
  };

  const getPaymentStatusColor = (status?: string) => {
    const s = (status || '').toLowerCase();
    switch(s) {
      case 'paid': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'payment_pending': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'refunded': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'failed': return 'bg-rose-100 text-rose-800 border-rose-200';
      default: return 'bg-rose-50 text-rose-700 border-rose-200'; // unpaid
    }
  };

  const filteredOrders = orders.filter(o => 
    o.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (o.orderId && o.orderId.toLowerCase().includes(searchTerm.toLowerCase())) ||
    o.shippingDetails?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    o.shippingDetails?.phone?.includes(searchTerm)
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-brand-black">Order Management</h2>
        <p className="text-brand-gray-500">Track and update customer order fulfillment and payment verification.</p>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-brand-gray-200">
        <div className="relative max-w-md mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-gray-400" />
          <input 
            type="text"
            placeholder="Search by Order ID, Customer Name, or Phone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-brand-gray-50 border border-brand-gray-200 rounded-lg outline-none focus:border-emerald-600 text-sm"
          />
        </div>

        {loading ? (
          <div className="py-10 text-center text-brand-gray-500">Loading order database...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-brand-gray-500 uppercase bg-brand-gray-50">
                <tr>
                  <th className="px-4 py-3 rounded-tl-lg">Order ID / Date</th>
                  <th className="px-4 py-3">Customer</th>
                  <th className="px-4 py-3">Payment Method</th>
                  <th className="px-4 py-3">Total Amount</th>
                  <th className="px-4 py-3">Payment Status</th>
                  <th className="px-4 py-3">Fulfillment Status</th>
                  <th className="px-4 py-3 rounded-tr-lg">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-gray-100">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-4 py-8 text-center text-brand-gray-500">
                      No orders found matching your search.
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map(o => {
                    const currentOrderStatus = o.orderStatus || o.status || 'pending';
                    const currentPaymentStatus = o.paymentStatus || (currentOrderStatus === 'paid' ? 'paid' : 'unpaid');
                    return (
                      <tr key={o.id} className="hover:bg-brand-gray-50/80 transition-colors">
                        <td className="px-4 py-3">
                          <div className="font-mono font-bold text-brand-black text-xs">{o.orderId || o.id}</div>
                          <div className="text-[11px] text-brand-gray-400 mt-0.5">
                            {(o.createdAt as any)?.seconds ? format(new Date((o.createdAt as any).seconds * 1000), 'MMM d, yyyy HH:mm') : typeof o.createdAt === 'string' ? o.createdAt.slice(0, 16) : 'N/A'}
                          </div>
                          {o.stockConflict && (
                            <div className="mt-1 inline-flex items-center gap-1 text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded px-1.5 py-0.5">
                              <AlertTriangle className="w-3 h-3" /> Stock conflict
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-medium text-brand-black">{o.shippingDetails?.name || 'Guest Customer'}</div>
                          <div className="text-xs text-brand-gray-500">{o.shippingDetails?.phone}</div>
                        </td>
                        <td className="px-4 py-3 text-xs text-brand-gray-600 font-medium">
                          {o.paymentMethod || 'Cash on Delivery'}
                        </td>
                        <td className="px-4 py-3 font-semibold text-brand-black">
                          ₹{o.grandTotal || o.amount}
                        </td>
                        <td className="px-4 py-3">
                          <select 
                            value={currentPaymentStatus}
                            onChange={(e) => updatePaymentStatus(o.id, e.target.value)}
                            className={`text-xs font-semibold rounded-lg px-2 py-1 border outline-none cursor-pointer ${getPaymentStatusColor(currentPaymentStatus)}`}
                          >
                            <option value="unpaid">🔴 Unpaid</option>
                            <option value="payment_pending">⏳ Payment Pending</option>
                            <option value="paid">🟢 Paid</option>
                            <option value="refunded">🟣 Refunded</option>
                            <option value="failed">❌ Failed</option>
                          </select>
                        </td>
                        <td className="px-4 py-3">
                          <select 
                            value={currentOrderStatus}
                            onChange={(e) => updateOrderStatus(o.id, e.target.value)}
                            className={`text-xs font-semibold rounded-lg px-2 py-1 border outline-none cursor-pointer ${getOrderStatusColor(currentOrderStatus)}`}
                          >
                            <option value="pending">🟡 Pending</option>
                            <option value="confirmed">🔵 Confirmed</option>
                            <option value="packed">📦 Packed</option>
                            <option value="dispatched">🚚 Dispatched</option>
                            <option value="out_for_delivery">🛵 Out for Delivery</option>
                            <option value="delivered">✅ Delivered</option>
                            <option value="cancelled">🔴 Cancelled</option>
                          </select>
                        </td>
                        <td className="px-4 py-3">
                          <button
                            onClick={() => setSelectedOrder(o)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" /> Details
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-6 shadow-2xl relative">
            <div className="flex items-center justify-between border-b pb-4">
              <div>
                <h3 className="text-lg font-bold text-brand-black">Order Summary</h3>
                <p className="text-xs text-brand-gray-500 font-mono">ID: {selectedOrder.orderId || selectedOrder.id}</p>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="p-2 text-brand-gray-400 hover:text-brand-black rounded-full hover:bg-brand-gray-100">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 text-sm bg-brand-gray-50 p-4 rounded-xl border">
              <div>
                <span className="text-xs text-brand-gray-500 block uppercase font-bold">Delivery Address</span>
                <p className="font-semibold text-brand-black">{selectedOrder.shippingDetails?.name}</p>
                <p className="text-brand-gray-600">{selectedOrder.shippingDetails?.phone}</p>
                <p className="text-brand-gray-600">{selectedOrder.shippingDetails?.address}</p>
                {selectedOrder.shippingDetails?.pincode && (
                  <p className="text-brand-gray-600 font-mono">Pincode: {selectedOrder.shippingDetails.pincode}</p>
                )}
              </div>
              <div>
                <span className="text-xs text-brand-gray-500 block uppercase font-bold">Payment & Status</span>
                <p className="text-brand-gray-700">Method: <strong>{selectedOrder.paymentMethod || 'COD'}</strong></p>
                <p className="text-brand-gray-700">Order Status: <strong className="capitalize">{selectedOrder.orderStatus || selectedOrder.status}</strong></p>
                <p className="text-brand-gray-700">Payment Status: <strong className="capitalize">{selectedOrder.paymentStatus || 'unpaid'}</strong></p>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold text-brand-black mb-3">Order Items ({selectedOrder.items.length})</h4>
              <div className="divide-y border rounded-xl overflow-hidden">
                {selectedOrder.items.map((item, idx) => (
                  <div key={idx} className="p-3 flex items-center justify-between bg-white text-sm">
                    <div className="flex items-center gap-3">
                      {item.image && (
                        <img src={item.image} alt={item.name} className="w-10 h-10 object-cover rounded-lg border shrink-0" />
                      )}
                      <div>
                        <p className="font-semibold text-brand-black">{item.name}</p>
                        {(item.selectedWeight || item.selectedCut) && (
                          <p className="text-xs text-brand-gray-500">
                            {item.selectedWeight && `Weight: ${item.selectedWeight}`}
                            {item.selectedWeight && item.selectedCut && ` • `}
                            {item.selectedCut && `Cut: ${item.selectedCut}`}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{item.quantity} × ₹{item.price}</p>
                      <p className="font-bold text-emerald-700">₹{item.quantity * item.price}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t pt-4 space-y-1 text-sm text-right">
              {typeof selectedOrder.subtotal === 'number' && (
                <p className="text-brand-gray-600">Subtotal: ₹{selectedOrder.subtotal}</p>
              )}
              {!!selectedOrder.discountAmount && (
                <p className="text-emerald-600">
                  Discount{selectedOrder.couponCode ? ` (${selectedOrder.couponCode})` : ''}: -₹{selectedOrder.discountAmount}
                </p>
              )}
              {typeof selectedOrder.deliveryFee === 'number' && (
                <p className="text-brand-gray-600">Delivery Fee: {selectedOrder.deliveryFee > 0 ? `₹${selectedOrder.deliveryFee}` : 'FREE'}</p>
              )}
              <p className="text-lg font-bold text-brand-black">Grand Total: ₹{selectedOrder.grandTotal || selectedOrder.amount}</p>
              {selectedOrder.stockConflict && (
                <p className="text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2 mt-2 text-left">
                  ⚠ Inventory conflict: {selectedOrder.stockConflictReason || 'stock ran out after this order was placed.'} Payment was already captured -- review and contact the customer if a backorder or partial refund is needed.
                </p>
              )}
              {selectedOrder.cancelReason && (
                <p className="text-xs font-semibold text-brand-gray-500 text-left">Cancel reason: {selectedOrder.cancelReason}</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
