import { useState, useEffect } from 'react';
import { collection, query, limit, onSnapshot } from 'firebase/firestore';
import { db } from '../../../services/firebase';
import { Product } from '../../../types';
import { PRODUCTS as defaultProducts } from '../../../constants/data';
import { getOptimizedImageUrl } from '../../../utils/imageUtils';

export function useStorefrontProducts() {
  const [dbProducts, setDbProducts] = useState<Product[]>([]);
  const [isProductsLoading, setIsProductsLoading] = useState(true);
  
  // Failsafe timeout to prevent infinite buffering if Firestore is not provisioned or slow
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsProductsLoading(false);
    }, 1500); // 1.5s max wait for products
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'products'), limit(500));

    const unsub = onSnapshot(
      q,
      (snap) => {
        const loaded: Product[] = [];
        snap.forEach((doc) => {
          const data = doc.data();
          if (!data.isDeleted) {
            loaded.push({ 
              id: doc.id, 
              ...data,
              image: getOptimizedImageUrl(data.image, 500, 80)
            } as Product);
          }
        });

        // Only fallback to defaults if database is entirely empty (first load before seeding)
        if (loaded.length === 0) {
          setDbProducts(defaultProducts.map(p => ({ ...p, image: getOptimizedImageUrl(p.image, 500, 80) })));
        } else {
          setDbProducts(loaded);
        }
        setIsProductsLoading(false);
      },
      (err) => {
        console.warn('Firestore snapshot error in storefront, falling back to default products:', err);
        setDbProducts(defaultProducts.map(p => ({ ...p, image: getOptimizedImageUrl(p.image, 500, 80) })));
        setIsProductsLoading(false);
      }
    );

    return () => {
      unsub();
    };
  }, []);

  const currentProducts = isProductsLoading 
     ? defaultProducts.map(p => ({ ...p, image: getOptimizedImageUrl(p.image, 500, 80) }))
     : (dbProducts.length > 0 ? dbProducts : defaultProducts.map(p => ({ ...p, image: getOptimizedImageUrl(p.image, 500, 80) })));

  return { currentProducts, dbProducts, isProductsLoading };
}
