import { useState, useEffect } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../../../services/firebase';
import { Category } from '../../../types';
import { CATEGORIES as defaultCategories } from '../../../constants/data';

export function useStorefrontCategories() {
  const [categoriesList, setCategoriesList] = useState<Category[]>(defaultCategories);

  useEffect(() => {
    const unsubCats = onSnapshot(
      collection(db, 'categories'),
      (snap) => {
        const loaded: Category[] = [];
        snap.forEach((doc) => {
          loaded.push({ id: doc.id, ...doc.data() } as Category);
        });
        const catMap = new Map<string, Category>();
        defaultCategories.forEach((c) => catMap.set(c.id, c));
        loaded.forEach((c) => {
          if ((c as any).isDeleted) {
            catMap.delete(c.id);
          } else {
            catMap.set(c.id, c);
          }
        });
        const merged = Array.from(catMap.values());
        if (merged.length > 0) {
          setCategoriesList(merged);
        }
      },
      (err) => {
        console.warn('Categories snapshot failed:', err);
      }
    );
    return () => unsubCats();
  }, []);

  return { categoriesList };
}
