import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartProduct, AuthUser } from '../types';
import { auth, db } from '../services/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { onAuthStateChanged, signOut, getRedirectResult } from 'firebase/auth';
import { ADMIN_EMAILS } from '../constants/admins';

interface CartItem extends CartProduct {
  quantity: number;
}

export interface FlyingItem {
  id: string;
  image: string;
  startX: number;
  startY: number;
}

interface CartContextType {
  items: CartItem[];
  addToCart: (product: CartProduct, quantity?: number) => void;
  removeFromCart: (id: string | number) => void;
  updateQuantity: (id: string | number, quantity: number) => void;
  cartTotal: number;
  cartCount: number;
  clearCart: () => void;
  user: AuthUser | null;
  logoutUser: () => void;
  isAuthLoading: boolean;
  searchQuery: string;
  wishlist: string[];
  toggleWishlist: (id: string) => void;
  setSearchQuery: (query: string) => void;
  addedItemToast: { id: string; name: string } | null;
  setAddedItemToast: (toast: { id: string; name: string } | null) => void;
  flyingItems: FlyingItem[];
  triggerFlyingItem: (item: Omit<FlyingItem, 'id'>) => void;
  removeFlyingItem: (id: string) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const getValidPrice = (item: any) => {
  const p1 = Number(item.numericPrice);
  if (!isNaN(p1) && p1 > 0) return p1;
  const p2 = parseFloat(String(item.price).replace(/[^0-9.]/g, ""));
  return isNaN(p2) ? 0 : p2;
};
export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => { try { const local = localStorage.getItem('jiyoo_cart'); return local ? JSON.parse(local) : []; } catch { return []; } });
  useEffect(() => { localStorage.setItem('jiyoo_cart', JSON.stringify(items)); }, [items]);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [wishlist, setWishlist] = useState<string[]>(() => { try { const local = localStorage.getItem('jiyoo_wishlist'); return local ? JSON.parse(local) : []; } catch { return []; } });
  useEffect(() => { localStorage.setItem('jiyoo_wishlist', JSON.stringify(wishlist)); }, [wishlist]);
  const [addedItemToast, setAddedItemToast] = useState<{ id: string; name: string } | null>(null);
  const [flyingItems, setFlyingItems] = useState<FlyingItem[]>([]);

  const triggerFlyingItem = React.useCallback((item: Omit<FlyingItem, 'id'>) => {
    const id = Math.random().toString(36).substring(7);
    setFlyingItems(prev => [...prev, { ...item, id }]);
  }, []);


  const toggleWishlist = React.useCallback((id: string) => {
    setWishlist(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  }, []);

  const removeFlyingItem = React.useCallback((id: string) => {
    setFlyingItems(prev => prev.filter(item => item.id !== id));
  }, []);

  useEffect(() => {
    // Handle redirect result for mobile Safari / iOS
    getRedirectResult(auth).catch((err) => {
      console.warn("Redirect auth check:", err);
    });

    // Safety fallback if Firebase Auth is broken
    const fallbackTimeout = setTimeout(() => { setIsAuthLoading(false); }, 2000);
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => { 
      clearTimeout(fallbackTimeout);
      if (firebaseUser) {
        let role = 'user';
        if (firebaseUser.email && ADMIN_EMAILS.includes(firebaseUser.email)) {
          role = 'admin';
        }
        
        const userData = {
          id: firebaseUser.uid,
          name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
          email: firebaseUser.email || '',
          picture: firebaseUser.photoURL || undefined,
          role,
        };
        
        setUser(userData);
        setIsAuthLoading(false); // Unblock immediately
        
        try {
          const userDocRef = doc(db, 'users', firebaseUser.uid);
          const userDocSnap = await Promise.race([
            getDoc(userDocRef),
            new Promise((_, reject) => setTimeout(() => reject(new Error('Firestore timeout - Database might not be enabled')), 3000))
          ]) as any;
          
          if (userDocSnap.exists()) {
            const data = userDocSnap.data();
            const dbRole = data.role;
            if (role !== 'admin' && dbRole) {
              role = dbRole;
            }
            if (data.wishlist) {
              setWishlist(data.wishlist);
            }
            setUser(prev => prev ? { ...prev, role, phone: data.phone, address: data.address, pincode: data.pincode } : prev);
          }
          
          // Upsert user in Firestore
          await setDoc(userDocRef, {
            ...userData,
            role,
            lastLogin: serverTimestamp(),
          }, { merge: true });
        
        } catch (error: any) {
          // If the network is offline or blocked, suppress the error
          if (error?.message?.includes('offline')) {
            console.warn("Firestore offline, defaulting to local cache/role.");
          } else {
            console.warn("Could not fetch user role:", error.message);
          }
        }
      } else {
        setUser(null);
        setIsAuthLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  const addToCart = React.useCallback((product: CartProduct, quantity: number = 1) => {
    setItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      const numPrice = product.numericPrice ?? (typeof product.price === 'number' ? product.price : parseFloat(String(product.price).replace(/[^0-9.]/g, '')) || 0);
      return [...prev, { ...product, numericPrice: numPrice, quantity }];
    });

    // Trigger premium notification toast
    setAddedItemToast({ id: String(product.id), name: product.name });
  }, []);

  const removeFromCart = React.useCallback((id: string | number) => {
    setItems(prev => prev.filter(item => String(item.id) !== String(id)));
  }, []);

  const updateQuantity = React.useCallback((id: string | number, quantity: number) => {
    if (quantity <= 0) {
      setItems(prev => prev.filter(item => String(item.id) !== String(id)));
    } else {
      setItems(prev => prev.map(item => String(item.id) === String(id) ? { ...item, quantity } : item));
    }
  }, []);

  const clearCart = React.useCallback(() => setItems([]), []);

  const logoutUser = React.useCallback(async () => {
    try {
      await signOut(auth);
      setItems([]);
      setWishlist([]);
      localStorage.removeItem('jiyoo_cart');
      localStorage.removeItem('jiyoo_wishlist');
    } catch (error) {
      console.error("Error signing out:", error);
    }
  }, []);

  const cartTotal = items.reduce((sum, item) => sum + (getValidPrice(item) * item.quantity), 0);
  const cartCount = items.reduce((sum, item) => sum + item.quantity, 0);


  const contextValue = React.useMemo(() => ({
    items,
    addToCart,
    removeFromCart,
    updateQuantity,
    cartTotal,
    cartCount,
    clearCart,
    user,
    logoutUser,
    isAuthLoading,
    searchQuery,
    setSearchQuery,
    wishlist,
    toggleWishlist,
    addedItemToast,
    setAddedItemToast,
    flyingItems,
    triggerFlyingItem,
    removeFlyingItem
  }), [items, cartTotal, cartCount, user, isAuthLoading, searchQuery, wishlist, addedItemToast, flyingItems]);

  return (
    <CartContext.Provider value={contextValue}>
      {children}
    </CartContext.Provider>
  );

}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}


