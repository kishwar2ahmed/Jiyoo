import { collection, addDoc, serverTimestamp, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';

export interface AuditLogEntry {
  id?: string;
  action: string;
  category: 'USERS' | 'SETTINGS' | 'BILLING' | 'DANGER_ZONE' | 'ORDERS' | 'SYSTEM';
  actor: string;
  details: string;
  createdAt?: any;
}

export async function logAuditEvent(
  action: string,
  category: AuditLogEntry['category'],
  actor: string,
  details: string
) {
  try {
    await addDoc(collection(db, 'audit_logs'), {
      action,
      category,
      actor: actor || 'Admin',
      details,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    console.warn('Could not write audit log to Firestore:', err);
    // Best-effort fallback -- must never itself throw, since every call site fires
    // this without awaiting/catching. A corrupted or quota-exceeded localStorage
    // entry here would otherwise surface as an unhandled promise rejection on
    // routine admin actions (role changes, exports, invoice downloads, etc.).
    try {
      const existing = JSON.parse(localStorage.getItem('jiyoo_audit_logs') || '[]');
      existing.unshift({
        id: 'local_' + Date.now(),
        action,
        category,
        actor: actor || 'Admin',
        details,
        createdAt: new Date().toISOString(),
      });
      localStorage.setItem('jiyoo_audit_logs', JSON.stringify(existing.slice(0, 50)));
    } catch (fallbackErr) {
      console.warn('Could not write audit log to local storage either:', fallbackErr);
    }
  }
}
