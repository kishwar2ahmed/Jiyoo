# Architecture & Folder Structure

## Project Structure
The project follows a feature-based architecture to promote modularity and scale.

```
src/
├── assets/          # Static assets like images
├── constants/       # Global constants and dummy data
├── contexts/        # React Contexts (Settings, Cart)
├── features/        # Feature modules
│   ├── admin/       # Admin panel (products, orders, settings)
│   ├── auth/        # Authentication components
│   ├── cart/        # Shopping cart and checkout
│   ├── core/        # Core components (UI, layout, error boundaries)
│   ├── product/     # Product display and details
│   └── storefront/  # Storefront homepage components
├── layouts/         # Page layouts (Navbar, Footer)
├── services/        # External services integration (Firebase, FCM)
├── styles/          # Global CSS
├── types/           # TypeScript interfaces and types
└── utils/           # Helper functions
```

## Data Flow
- **State Management**: React Context (`CartContext`, `SettingsContext`) manages global state.
- **Data Fetching**: The app interfaces directly with Firebase Firestore using the client SDK. Real-time updates are handled using `onSnapshot`.
- **Authentication**: Managed via Firebase Auth. The `useCart` hook doubles as an auth context in this setup for simplicity.
- **Payments**: The checkout process makes a POST request to `/api/razorpay/order` (handled by Express in dev or Netlify Functions in prod) to create an order. The frontend initializes Razorpay Checkout, and success calls `/api/razorpay/verify`.
