# JIYOO Premium Products

JIYOO is a modern e-commerce platform built with React, Vite, Tailwind CSS, and Firebase. It provides a seamless shopping experience for premium products, featuring Razorpay payment integration, a full-featured admin panel, order tracking, and more.

## Quick Start

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm run dev
   ```

## Tech Stack
- Frontend: React 19, TypeScript, Tailwind CSS, Vite
- Backend: Express (Serverless via Netlify Functions)
- Database: Firebase Firestore
- Storage: Firebase Storage
- Auth: Firebase Authentication
- Payments: Razorpay

For detailed setup instructions, please see [SETUP.md](SETUP.md).
