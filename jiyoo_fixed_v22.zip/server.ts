
process.on('uncaughtException', (err: any) => {
  const errStr = String(err?.message || err);
  if (errStr.includes('The database (default) does not exist') || errStr.includes('firestore')) {
    console.warn('Firebase DB not initialized (Server Exception):', errStr);
    return; // Don't crash
  }
  // Process state may be corrupted after a sync exception -- exit and let a process
  // manager restart cleanly rather than keep serving from an unknown state.
  console.error('UNCAUGHT EXCEPTION! Shutting down...', err);
  process.exit(1);
});

process.on('unhandledRejection', (reason: any, promise) => {
  const reasonStr = String(reason?.message || reason);
  if (reasonStr.includes('The database (default) does not exist') || reasonStr.includes('firestore')) {
    console.warn('Firebase DB not initialized (Server):', reasonStr);
    return; // Don't crash
  }
  // Log and keep serving -- every route below has its own try/catch, so a rejection
  // reaching here is an outlier and shouldn't take down active requests for other users.
  console.error('UNHANDLED REJECTION (server stays up):', reason);
});
import express from 'express';
import dotenv from 'dotenv';
dotenv.config();

import compression from 'compression';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import cookieParser from 'cookie-parser';
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import Razorpay from 'razorpay';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';

import { initializeApp, getApps, cert } from 'firebase-admin/app';
import { getMessaging } from 'firebase-admin/messaging';
import { getFirestore } from 'firebase-admin/firestore';
import { getStorage } from 'firebase-admin/storage';
import { getAuth } from 'firebase-admin/auth';

import { PRODUCTS } from './src/constants/data';
import { ADMIN_EMAILS } from './src/constants/admins';

const PORT = Number(process.env.PORT) || 3000;

const envSchema = z.object({
  NODE_ENV: z.string().optional().default('development'),
  PORT: z.string().optional().default('3000'),
  FIREBASE_SERVICE_ACCOUNT_KEY: z.string().optional(),
  FIREBASE_STORAGE_BUCKET: z.string().optional().default('jiyoo-7.firebasestorage.app'),
  RAZORPAY_KEY_ID: z.string().optional(),
  RAZORPAY_KEY_SECRET: z.string().optional(),
  RAZORPAY_WEBHOOK_SECRET: z.string().optional(),
  SMTP_HOST: z.string().optional(),
  SMTP_PORT: z.string().optional().default('587'),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),
  SMTP_FROM: z.string().optional(),
  GEMINI_API_KEY: z.string().optional(),
});

let env: z.infer<typeof envSchema>;
try {
  env = envSchema.parse(process.env);
} catch (err: any) {
  console.error('CRITICAL: Environment variable validation failed:', err);
  process.exit(1);
}

// Initialize Firebase Admin SDK
if (!getApps().length) {
  try {
    const serviceAccountJson = env.FIREBASE_SERVICE_ACCOUNT_KEY;
    if (serviceAccountJson) {
      let parsedServiceAccount = null;
      try {
        parsedServiceAccount = JSON.parse(serviceAccountJson);
      } catch (e) {
        console.warn('FIREBASE_SERVICE_ACCOUNT_KEY is not valid JSON, falling back to default initialization.');
      }
      
      if (parsedServiceAccount) {
        initializeApp({
          credential: cert(parsedServiceAccount),
          storageBucket: env.FIREBASE_STORAGE_BUCKET,
        });
      } else {
        initializeApp({
          storageBucket: env.FIREBASE_STORAGE_BUCKET,
        });
      }
    } else {
      initializeApp({
        storageBucket: env.FIREBASE_STORAGE_BUCKET,
      });
    }
  } catch (error) {
    console.error('Firebase Admin initialization error:', error);
  }
}

// Helper to dynamically obtain Razorpay instance
function getRazorpay() {
  if (env.RAZORPAY_KEY_ID && env.RAZORPAY_KEY_SECRET) {
    return new Razorpay({
      key_id: env.RAZORPAY_KEY_ID,
      key_secret: env.RAZORPAY_KEY_SECRET,
    });
  }
  return null;
}

// Escapes user-supplied text before interpolating into HTML email templates.
function sanitizeHTML(str: any): string {
  if (typeof str !== 'string') return String(str || '');
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}


function formatServerError(errorMsg: string): string {
  if (errorMsg.includes('What happened:') && errorMsg.includes('Why it happened:')) {
    return errorMsg;
  }
  
  let what = "A server operation failed.";
  let why = errorMsg || "Unknown server error.";
  let next = "Please try again or contact support if the problem persists.";

  const lowerMsg = errorMsg.toLowerCase();
  
  if (lowerMsg.includes(' auth ') || lowerMsg.includes('token') || lowerMsg.includes('admin') || lowerMsg.includes('unauthorized')) {
    what = "Authentication or permission denied.";
    why = errorMsg || "Your session may be invalid or you lack necessary permissions.";
    next = "Log out and log back in, or check your account permissions.";
  } else if (lowerMsg.includes('price') || lowerMsg.includes('inventory') || lowerMsg.includes('mismatch')) {
    what = "Order validation failed.";
    why = errorMsg;
    next = "Please clear your cart, refresh the page, and try again.";
  } else if (lowerMsg.includes('payment') || lowerMsg.includes('razorpay') || lowerMsg.includes('signature')) {
    what = "Payment processing failed.";
    why = errorMsg;
    next = "Try a different payment method or try again. Refunds for deducted amounts will be processed automatically.";
  } else if (lowerMsg.includes('payload') || lowerMsg.includes('missing') || lowerMsg.includes('invalid')) {
    what = "Invalid request format.";
    why = errorMsg;
    next = "Please check your inputs and try again.";
  }

  return `What happened: \n${what}\n\nWhy it happened: \n${why}\n\nWhat to do next: \n${next}`;
}

// Set up rate limiting

// Stricter rate limiting for sensitive/paid endpoints
const strictApiLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour window
  max: 10, // start blocking after 10 requests
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests for this service, please try again after an hour' },
});

// Moderate rate limit for order creation
const orderLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes window
  max: 20, // start blocking after 20 requests
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many order requests, please try again later' },
});

// Order tracking is reachable without auth (orderId + phone digits), so it needs its
// own tight limiter -- otherwise it's a brute-forceable lookup against the 4-digit
// random suffix in generateOrderId() for a known/guessed phone number.
const trackOrderLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour window
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many order lookup attempts. Please try again later.' },
});

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests from this IP, please try again after 15 minutes' },
});



async function optionalAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return next();
  try {
    (req as any).authUser = await getAuth().verifyIdToken(token);
  } catch (err) {
    // If token is invalid, we proceed as guest, or you could reject. Rejecting is safer.
    return res.status(401).json({ success: false, error: 'Invalid or expired auth token' });
  }
  next();
}

async function requireAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ success: false, error: 'Missing auth token' });
  try {
    (req as any).authUser = await getAuth().verifyIdToken(token);
    next();
  } catch {
    res.status(401).json({ success: false, error: 'Invalid or expired token' });
  }
}

async function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  try {
    const authUser = (req as any).authUser;
    if (ADMIN_EMAILS.includes(authUser?.email)) return next();
    const snap = await getFirestore().collection('users').doc(authUser.uid).get();
    if (snap.exists && snap.data()?.role === 'admin') return next();
    res.status(403).json({ success: false, error: 'Admin only' });
  } catch (err) {
    console.error('requireAdmin check failed:', err);
    res.status(503).json({ success: false, error: 'Unable to verify admin access right now. Please try again.' });
  }
}

// ENTERPRISE LOGIC: Strict transactional inventory locking
async function decrementInventory(items: any[]) {
  const db = getFirestore();
  
  // Resolve base IDs since cart item IDs might be composite (e.g. "prod_1-500g")
  const resolveBaseId = (item: any) => {
    if (item.baseId) return String(item.baseId);
    const idStr = String(item.id);
    return idStr.includes('-') ? idStr.split('-')[0] : idStr;
  };

  // Throws on insufficient stock instead of clamping to zero -- keeps the
  // check-and-decrement atomic so concurrent checkouts can't both sell the last unit.
  // Callers must catch and decide how to handle it (reject an unpaid order, or flag a
  // paid one for review).
  await db.runTransaction(async (transaction) => {
    // Read all products first (required by Firestore transactions)
    const productDocs = [];
    for (const item of items) {
      const productRef = db.collection('products').doc(resolveBaseId(item));
      const docSnap = await transaction.get(productRef);
      if (docSnap.exists) {
        productDocs.push({ ref: productRef, data: docSnap.data(), requestedQty: item.quantity, name: item.name });
      }
    }

    // Validate every item before writing any update, so the transaction fails
    // atomically instead of partially decrementing some items and not others.
    for (const p of productDocs) {
      if (typeof p.data.stock === 'number' && p.data.stock - p.requestedQty < 0) {
        throw new Error(`Insufficient stock for ${p.data.name || p.name || 'item'}. Available: ${p.data.stock}, requested: ${p.requestedQty}.`);
      }
    }

    for (const p of productDocs) {
      if (typeof p.data.stock === 'number') {
        transaction.update(p.ref, { stock: p.data.stock - p.requestedQty });
      }
    }
  });
}

async function calculateOrderTotals(items: any[]): Promise<{ subtotal: number, validatedItems: any[] }> {
  let subtotal = 0;
  const validatedItems: any[] = [];
  
  const resolveBaseId = (item) => {
    if (item.baseId) return String(item.baseId);
    const idStr = String(item.id);
    if (idStr.includes('-')) {
      return idStr.split('-')[0];
    }
    return idStr;
  };

  // Query Firestore & fallback catalog to determine authoritative item prices
  const productRefs = items.map(item => getFirestore().collection('products').doc(resolveBaseId(item)));
  let dbProducts: any[] = [];
  
  try {
    if (productRefs.length > 0) {
      const docRefs = await getFirestore().getAll(...productRefs);
      dbProducts = docRefs.map(doc => doc.exists ? { id: doc.id, ...doc.data() } : null);
    }
  } catch (dbErr) {
    console.warn('Firestore lookup warning during price calculation:', dbErr);
  }

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    let itemPrice = 0;
    
    const pData = dbProducts[i];
    if (pData) {
      if (item.selectedWeight && Array.isArray(pData.weights)) {
        const weightOpt = pData.weights.find(
          (w: any) => w.label === item.selectedWeight || w.weight === item.selectedWeight
        );
        if (weightOpt && weightOpt.price) {
          itemPrice = Number(weightOpt.price) || parseFloat(String(weightOpt.price).replace(/[^0-9.]/g, '')) || 0;
        }
      }
      if (!itemPrice) {
        itemPrice = Number(pData.numericPrice) || parseFloat(String(pData.price).replace(/[^0-9.]/g, '')) || 0;
      }
    }

    if (!itemPrice) {
      const fallbackProd = PRODUCTS.find((p) => String(p.id) === resolveBaseId(item));
      if (fallbackProd) {
        if (item.selectedWeight && fallbackProd.weights) {
          const weightOpt = fallbackProd.weights.find(
            (w) => w.label === item.selectedWeight || w.weight === item.selectedWeight
          );
          if (weightOpt && weightOpt.price) {
            itemPrice = Number(weightOpt.price) || parseFloat(String(weightOpt.price).replace(/[^0-9.]/g, '')) || 0;
          }
        }
        if (!itemPrice) {
          itemPrice = Number(fallbackProd.numericPrice) || parseFloat(String(fallbackProd.price).replace(/[^0-9.]/g, '')) || 0;
        }
      }
    }

    if (!itemPrice) {
      throw new Error(`Price for item ${item.name || item.id} could not be determined. Server authoritative check failed.`);
    }
    if (itemPrice <= 0) {
      throw new Error(`Invalid product or missing price for item ID ${item.id}`);
    }

    if (pData && typeof pData.stock === 'number' && pData.stock >= 0) {
      if (pData.stock < item.quantity) {
        throw new Error(`Insufficient stock for ${pData.name || item.name}. Available: ${pData.stock}`);
      }
    }
    
    subtotal += itemPrice * item.quantity;
    
    validatedItems.push({
      id: item.id,
      name: pData?.name || PRODUCTS.find(p => String(p.id) === String(item.id))?.name || item.name || 'Item',
      quantity: item.quantity,
      price: itemPrice,
      selectedWeight: item.selectedWeight || null,
      selectedCut: item.selectedCut || null,
      image: pData?.image || PRODUCTS.find(p => String(p.id) === String(item.id))?.image || item.image || null,
    });
  }
  return { subtotal, validatedItems };
}

// Atomically claims a pending Razorpay order snapshot so that /verify and the
// webhook can never both build an order for the same payment if they race. Returns
// the pending data if this call won the claim, or null if it was already claimed
// (by the other path) or never existed.
async function claimPendingRazorpayOrder(razorpayOrderId: string): Promise<any | null> {
  const db = getFirestore();
  const pendingRef = db.collection('razorpayPendingOrders').doc(razorpayOrderId);
  return db.runTransaction(async (tx) => {
    const snap = await tx.get(pendingRef);
    if (!snap.exists) return null;
    const data = snap.data() as any;
    if (data.consumed) return null;
    tx.update(pendingRef, { consumed: true, consumedAt: new Date().toISOString() });
    return data;
  });
}

// Looks up an order by its Razorpay order id, retrying briefly -- used when this
// request lost the claim race to /verify or the webhook, so the winner's write has
// a moment to become visible.
async function findOrderByRazorpayId(razorpayOrderId: string, retries = 3): Promise<string | null> {
  const db = getFirestore();
  for (let i = 0; i < retries; i++) {
    const snap = await db.collection('orders').where('razorpay_order_id', '==', razorpayOrderId).limit(1).get();
    if (!snap.empty) return snap.docs[0].id;
    if (i < retries - 1) await new Promise((r) => setTimeout(r, 300));
  }
  return null;
}

// Reconciles a Razorpay payment against an order record. Acts as the webhook's
// safety net: if verify() already ran, ensures the order is marked paid; if the
// client never completed /api/razorpay/verify (tab closed, network drop, etc.),
// rebuilds the order from the pending snapshot saved in /api/razorpay/order.
async function reconcileRazorpayOrder(razorpayOrderId: string, paymentId?: string | null) {
  const db = getFirestore();

  const existing = await db.collection('orders').where('razorpay_order_id', '==', razorpayOrderId).limit(1).get();
  if (!existing.empty) {
    const docRef = existing.docs[0].ref;
    const data = existing.docs[0].data();
    if (data.paymentStatus !== 'paid') {
      await docRef.update({
        paymentStatus: 'paid',
        status: 'confirmed',
        orderStatus: 'confirmed',
        razorpay_payment_id: paymentId || data.razorpay_payment_id || null,
        updatedAt: new Date().toISOString(),
      });
      console.log(`[Webhook] Marked order ${docRef.id} as paid (was "${data.paymentStatus}").`);
    }
    return;
  }

  // No order exists yet -- /verify never completed on the client (or is racing this
  // request right now). Claim the pending snapshot atomically; if /verify already
  // claimed it, just wait for its order to appear instead of creating a duplicate.
  const pending = await claimPendingRazorpayOrder(razorpayOrderId);
  if (!pending) {
    const foundOrderId = await findOrderByRazorpayId(razorpayOrderId);
    if (!foundOrderId) {
      console.warn(`[Webhook] No pending snapshot (or already claimed) for Razorpay order ${razorpayOrderId}; could not reconcile.`);
    }
    return;
  }

  const orderId = generateOrderId();
  const orderPayload = {
    id: orderId,
    orderId,
    items: pending.items || [],
    subtotal: pending.subtotal || 0,
    discountAmount: pending.discountAmount || 0,
    couponCode: pending.couponCode || null,
    deliveryFee: pending.deliveryFee || 0,
    amount: pending.amount || 0,
    grandTotal: pending.amount || 0,
    status: 'confirmed',
    orderStatus: 'confirmed',
    paymentStatus: 'paid',
    paymentMethod: 'Online Payment (Razorpay)',
    razorpay_order_id: razorpayOrderId,
    razorpay_payment_id: paymentId || null,
    shippingDetails: pending.shippingDetails || {},
    userId: pending.userId || 'guest',
    createdViaWebhook: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  await db.collection('orders').doc(orderId).set(orderPayload);
  try {
    await decrementInventory(orderPayload.items);
  } catch (stockErr: any) {
    console.error(`[Webhook] Inventory conflict on auto-created order ${orderId}:`, stockErr.message);
    await db.collection('orders').doc(orderId).update({ stockConflict: true, stockConflictReason: stockErr.message });
  }
  console.log(`[Webhook] Auto-created order ${orderId} from Razorpay payment ${paymentId} (client /verify never completed).`);
}

async function getStoreDeliverySettings(): Promise<{ deliveryFee: number; freeDeliveryThreshold: number }> {
  try {
    const docSnap = await getFirestore().collection('settings').doc('global').get();
    if (docSnap.exists) {
      const data = docSnap.data();
      const fee = typeof data?.deliveryFee === 'number' ? data.deliveryFee : 40;
      const threshold = typeof data?.freeDeliveryThreshold === 'number' ? data.freeDeliveryThreshold : 0;
      return { deliveryFee: fee, freeDeliveryThreshold: threshold };
    }
  } catch (err) {
    console.warn('Error reading store settings:', err);
  }
  return { deliveryFee: 40, freeDeliveryThreshold: 0 };
}

function generateOrderId(): string {
  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  return `JY-${dateStr}-${randomSuffix}`;
}

// Authoritative server-side coupon validation against the `coupons` collection
// (the same one the Admin Panel's Promotions tab manages). Throws a user-facing
// message if the code is invalid, inactive, or below the minimum order value.
async function applyCoupon(subtotal: number, couponCode?: string | null): Promise<{ discountAmount: number; couponCode: string | null }> {
  if (!couponCode || !String(couponCode).trim()) {
    return { discountAmount: 0, couponCode: null };
  }
  const code = String(couponCode).trim().toUpperCase();

  const snap = await getFirestore().collection('coupons').doc(code).get();
  if (!snap.exists) {
    throw new Error(`Coupon code "${code}" is not valid.`);
  }
  const coupon = snap.data() as any;
  if (coupon.isActive === false) {
    throw new Error(`Coupon code "${code}" is no longer active.`);
  }
  const minOrderValue = Number(coupon.minOrderValue) || 0;
  if (minOrderValue > 0 && subtotal < minOrderValue) {
    throw new Error(`Coupon "${code}" requires a minimum order of ₹${minOrderValue}.`);
  }

  let discountAmount: number;
  if (coupon.discountType === 'percentage') {
    discountAmount = (subtotal * (Number(coupon.discountValue) || 0)) / 100;
  } else {
    discountAmount = Number(coupon.discountValue) || 0;
  }
  // Never let a discount exceed the subtotal (e.g. a flat-₹ coupon on a small cart).
  discountAmount = Math.round(Math.max(0, Math.min(discountAmount, subtotal)) * 100) / 100;

  return { discountAmount, couponCode: code };
}

const directOrderSchema = z.object({
  items: z.array(
    z.object({
      id: z.union([z.string(), z.number()]),
      baseId: z.union([z.string(), z.number()]).optional(),
      name: z.string().optional(),
      quantity: z.number().int().positive(),
      price: z.number().optional(),
      selectedWeight: z.string().nullable().optional(),
      selectedCut: z.string().nullable().optional(),
      image: z.string().optional(),
    })
  ).min(1, 'Cart cannot be empty'),
  // Fields are optional at the schema level and validated conditionally in the handler,
  // since WhatsApp Express quick-orders intentionally don't collect a delivery address
  // up front (the customer sends it via WhatsApp chat instead).
  shippingDetails: z.object({
    name: z.string().optional().default(''),
    phone: z.string().optional().default(''),
    address: z.string().optional().default(''),
    pincode: z.string().optional().default(''),
  }),
  paymentMethod: z.string().default('Cash on Delivery'),
  userId: z.string().optional().default('guest'),
  utrNumber: z.string().optional(),
  couponCode: z.string().optional().nullable(),
});

const trackOrderSchema = z.object({
  orderId: z.string().min(1, 'Order ID is required'),
  phone: z.string().optional(),
});

const couponItemsSchema = z.array(
  z.object({
    id: z.union([z.string(), z.number()]),
    baseId: z.union([z.string(), z.number()]).optional(),
    quantity: z.number().int().positive().default(1),
    selectedWeight: z.string().nullable().optional(),
    selectedCut: z.string().nullable().optional(),
  })
).min(1, 'Cart cannot be empty');

const couponValidateSchema = z.object({
  code: z.string().min(1, 'Coupon code is required'),
  items: couponItemsSchema,
});

const createOrderSchema = z.object({
  items: z.array(
    z.object({
      id: z.union([z.string(), z.number()]),
      baseId: z.union([z.string(), z.number()]).optional(),
      quantity: z.number().int().positive().default(1),
      selectedWeight: z.string().nullable().optional(),
      selectedCut: z.string().nullable().optional(),
    })
  ).min(1, 'Order must contain at least one item'),
  currency: z.string().optional().default('INR'),
  couponCode: z.string().optional().nullable(),
  // Captured here (not just at /verify) so a Razorpay webhook that arrives without a
  // matching client-side /verify call still has enough info to build the order record.
  shippingDetails: z.object({
    name: z.string().optional(),
    phone: z.string().optional(),
    address: z.string().optional(),
    pincode: z.string().optional(),
  }).optional(),
});

const verifyPaymentSchema = z.object({
  razorpay_order_id: z.string().min(1, 'Order ID is required'),
  razorpay_payment_id: z.string().min(1, 'Payment ID is required'),
  razorpay_signature: z.string().min(1, 'Signature is required'),
  items: z.array(
    z.object({
      id: z.union([z.string(), z.number()]),
      baseId: z.union([z.string(), z.number()]).optional(),
      quantity: z.number().int().positive().default(1),
      selectedWeight: z.string().nullable().optional(),
      selectedCut: z.string().nullable().optional(),
      name: z.string().optional(),
      price: z.number().optional(),
      image: z.string().optional(),
    })
  ).min(1, 'Order must contain at least one item').optional(),
  shippingDetails: z.object({
    name: z.string().optional(),
    address: z.string().optional(),
    phone: z.string().optional(),
  }).optional(),
  userId: z.string().optional(),
  couponCode: z.string().optional().nullable(),
});

const uploadUrlSchema = z.object({
  filename: z.string().min(1, 'Filename is required'),
  contentType: z.string().min(1, 'Content type is required'),
});

const sendNotificationSchema = z.object({
  tokens: z.union([z.string(), z.array(z.string())]).optional(),
  userId: z.string().optional(),
  title: z.string().min(1, 'Notification title is required'),
  body: z.string().optional(),
  data: z.record(z.string(), z.any()).optional(),
});

const sendEmailSchema = z.object({
  email: z.string().email('Invalid email address'),
  storeName: z.string().optional().default('JIYOO'),
  order: z.object({
    id: z.string().optional(),
    amount: z.number().optional(),
    items: z.array(
      z.object({
        name: z.string(),
        quantity: z.number(),
        price: z.number(),
      })
    ).optional().default([]),
    shippingDetails: z.object({
      name: z.string().optional(),
      address: z.string().optional(),
      phone: z.string().optional(),
    }).optional(),
  }),
});

async function startServer() {
  const app = express();

  // =========================================================
  // SESSION MANAGEMENT (HTTP-Only Cookies)
  // =========================================================
  app.post('/api/sessionLogin', strictApiLimiter, async (req, res) => {
    const idToken = req.body.idToken?.toString();
    if (!idToken) return res.status(401).json({ error: 'UNAUTHORIZED REQUEST!' });

    const expiresIn = 60 * 60 * 24 * 5 * 1000; // 5 days
    try {
      const sessionCookie = await getAuth().createSessionCookie(idToken, { expiresIn });
      const options = { maxAge: expiresIn, httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict' as const };
      res.cookie('session', sessionCookie, options);
      res.json({ status: 'success' });
    } catch (error) {
      res.status(401).json({ error: 'UNAUTHORIZED REQUEST!' });
    }
  });

  app.post('/api/sessionLogout', (req, res) => {
    res.clearCookie('session');
    res.json({ status: 'success' });
  });
  app.set('trust proxy', 1);
  
app.use((req, res, next) => {
  const originalJson = res.json;
  res.json = function(body) {
    if (body && body.success === false && typeof body.error === 'string') {
      body.error = formatServerError(body.error);
    }
    return originalJson.call(this, body);
  };
  next();
});

app.use(compression());


  // Force HTTPS in production
  app.use((req, res, next) => {
    if (process.env.NODE_ENV === 'production' && req.headers['x-forwarded-proto'] && req.headers['x-forwarded-proto'] !== 'https') {
      return res.redirect('https://' + req.headers.host + req.url);
    }
    next();
  });

  // Security Middlewares
  app.use(
    helmet({
      frameguard: false,
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'", "https:", "http:", "data:", "blob:"],
          scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://checkout.razorpay.com", "https://apis.google.com"],
          styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
          fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
          imgSrc: ["'self'", "data:", "blob:", "https:", "http:"],
          connectSrc: ["'self'", "https:", "wss:", "ws:"],
          frameSrc: ["'self'", "https:", "https://checkout.razorpay.com"],
          // Restrict framing to same-origin to prevent clickjacking.
          frameAncestors: ["'self'"],
        },
      },
      crossOriginEmbedderPolicy: false,
    })
  );

  app.use(
    express.json({
      limit: '25mb',
      verify: (req, res, buf) => {
        (req as any).rawBody = buf.toString('utf8');
      },
    })
  );

  app.use(cookieParser());
  app.use('/api/', apiLimiter);

  // High-Quality Binary Image Upload Endpoint to public/uploads
  
  // Image retrieval endpoint (Firestore backed)
  app.get('/api/images/:id', async (req, res) => {
    try {
       const doc = await getFirestore().collection('_images').doc(req.params.id).get();
       if (!doc.exists) {
          return res.status(404).send('Image not found');
       }
       const data = doc.data();
       const buffer = Buffer.from(data.base64, 'base64');
       res.set('Content-Type', data.mimeType || 'image/jpeg');
       res.set('Cache-Control', 'public, max-age=31536000');
       res.send(buffer);
    } catch (e) {
       res.status(500).send('Failed to load image');
    }
  });

  // Admin-only. Not called anywhere in the frontend -- the actual image upload path
  // is ImageUpload.tsx, which writes straight to Firebase Storage under isAdmin() rules.
  app.post('/api/upload', strictApiLimiter, requireAuth, requireAdmin, async (req: express.Request, res: express.Response) => {
    try {
      const { image, filename } = req.body || {};
      if (!image) {
        return res.status(400).json({ success: false, error: 'No image payload provided' });
      }

      let buffer: Buffer;
      let extension = 'jpg';
      let mimeType = 'image/jpeg';

      if (typeof image === 'string' && image.startsWith('data:')) {
        const matches = image.match(/^data:image\/([a-zA-Z0-9+\-+.]+);base64,(.+)$/);
        if (!matches || matches.length !== 3) {
          return res.status(400).json({ success: false, error: 'Invalid base64 image format' });
        }
        
        const format = matches[1].toLowerCase();
        const allowedFormats = ['jpeg', 'jpg', 'png', 'webp'];
        if (!allowedFormats.includes(format)) {
           return res.status(400).json({ success: false, error: 'Unsupported file type. Only JPEG, PNG, and WebP are allowed.' });
        }
        
        if (format.includes('png')) { extension = 'png'; mimeType = 'image/png'; }
        else if (format.includes('webp')) { extension = 'webp'; mimeType = 'image/webp'; }
        else { extension = 'jpg'; mimeType = 'image/jpeg'; }
        
        buffer = Buffer.from(matches[2], 'base64');
      } else if (typeof image === 'string' && image.length > 20) {
        buffer = Buffer.from(image, 'base64');
        if (filename && filename.includes('.')) {
          extension = filename.split('.').pop() || 'jpg';
          if (extension === 'png') mimeType = 'image/png';
          else if (extension === 'webp') mimeType = 'image/webp';
        }
      } else {
        return res.status(400).json({ success: false, error: 'Image must be a base64 encoded string or Data URL' });
      }

      if (buffer.length === 0) {
        return res.status(400).json({ success: false, error: 'File buffer is empty' });
      }

      // Enforce max file size server-side (approx 1000KB for Firestore)
      if (buffer.length > 950 * 1024) {
         return res.status(413).json({ success: false, error: 'File size exceeds 950KB limit for database storage.' });
      }

      const safeBaseName = filename
        ? filename.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/\.[^/.]+$/, '')
        : 'image';
      const timestamp = Date.now();
      const finalFileName = `${safeBaseName}_${timestamp}.${extension}`;
      const docId = `img_${timestamp}_${Math.random().toString(36).substring(2, 9)}`;

      // Save to local public/uploads directory for zero-latency static serving.
      // Skipped on Vercel (and any other serverless host) -- their filesystem
      // is read-only outside /tmp, and a written file wouldn't persist or be
      // reachable across invocations anyway. The Firestore write below is the
      // real source of truth everywhere; /api/images/:id serves it back.
      if (!process.env.VERCEL) {
        try {
          const publicUploadsDir = path.join(process.cwd(), 'public', 'uploads');
          if (!fs.existsSync(publicUploadsDir)) {
            fs.mkdirSync(publicUploadsDir, { recursive: true });
          }
          const diskFilePath = path.join(publicUploadsDir, finalFileName);
          fs.writeFileSync(diskFilePath, buffer);
        } catch (fsErr) {
          console.warn('[Upload Warning] Could not write image to static disk:', fsErr);
        }
      }

      // Save to Firestore _images collection for persistence across instances.
      // This is the URL actually returned below (/api/images/:id), so it works
      // identically on a traditional server and on serverless.
      let savedToFirestore = false;
      try {
        if (buffer.length <= 950 * 1024) {
          await getFirestore().collection('_images').doc(docId).set({
             base64: buffer.toString('base64'),
             mimeType: mimeType,
             filename: finalFileName,
             createdAt: timestamp,
             size: buffer.length
          });
          savedToFirestore = true;
        }
      } catch (dbErr) {
        console.warn('[Upload Warning] Could not save image to Firestore _images collection:', dbErr);
      }

      if (!savedToFirestore) {
        return res.status(500).json({ success: false, error: 'Failed to persist uploaded image' });
      }

      const fileUrl = `/api/images/${docId}`;
      console.log(`[Upload Success] Saved image (${buffer.length} bytes) -> ${fileUrl}`);

      return res.status(200).json({
        success: true,
        url: fileUrl,
        filename: finalFileName,
        size: buffer.length,
      });
    } catch (err: any) {
      console.error('Image upload endpoint error:', err);
      return res.status(500).json({ success: false, error: err.message || 'Failed to upload image' });
    }
  });




// ENTERPRISE LOGIC: Securely update WhatsApp pending orders
app.post('/api/orders/:id/whatsapp-status', trackOrderLimiter, optionalAuth, async (req: express.Request, res: express.Response) => {
  try {
    const orderId = req.params.id;
    const { status } = req.body; // 'pending' or 'cancelled'
    
    if (status !== 'pending' && status !== 'cancelled') {
      return res.status(400).json({ success: false, error: 'Invalid status update' });
    }
    
    const db = getFirestore();
    const orderRef = db.collection('orders').doc(orderId);
    const orderSnap = await orderRef.get();
    
    if (!orderSnap.exists) {
      return res.status(404).json({ success: false, error: 'Order not found' });
    }
    
    const orderData = orderSnap.data();

    // SECURITY: If this order belongs to a signed-in account, only that
    // account (or an admin) may update it. Order IDs are short and
    // sequential, not secret, so without this check anyone who guesses an
    // ID could cancel another customer's order. Guest orders (userId
    // 'guest') have no account to check against, so they fall through.
    const authUser = (req as any).authUser;
    if (orderData?.userId && orderData.userId !== 'guest') {
      if (!authUser || (authUser.uid !== orderData.userId && !ADMIN_EMAILS.includes(authUser.email))) {
        return res.status(403).json({ success: false, error: 'Unauthorized to update this order' });
      }
    }

    // SECURITY: Only allow state transitions from 'whatsapp_pending'
    if (orderData?.status !== 'whatsapp_pending' && orderData?.orderStatus !== 'whatsapp_pending') {
      return res.status(403).json({ success: false, error: 'Order is no longer in pending verification state.' });
    }
    
    await orderRef.update({
      status: status,
      orderStatus: status,
      updatedAt: new Date().toISOString()
    });
    
    res.json({ success: true });
  } catch (e: any) {
    console.error('WhatsApp Status Update error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// Deletes a user's account server-side with the Admin SDK: anonymizes their orders,
// removes their reviews and profile doc, then deletes the Auth user record.
app.post('/api/account/delete', requireAuth, async (req: express.Request, res: express.Response) => {
  try {
    const authUser = (req as any).authUser;
    const uid = authUser.uid;
    const db = getFirestore();

    // 1. Anonymize (don't delete) this user's orders -- order records are typically
    // kept for accounting/audit purposes, but we remove the link to their account.
    const ordersSnap = await db.collection('orders').where('userId', '==', uid).get();
    if (!ordersSnap.empty) {
      const batch = db.batch();
      ordersSnap.forEach((docSnap) => {
        batch.update(docSnap.ref, { userId: 'deleted_user', accountDeleted: true });
      });
      await batch.commit();
    }

    // 2. Delete reviews written by this user.
    const reviewsSnap = await db.collection('reviews').where('userId', '==', uid).get();
    if (!reviewsSnap.empty) {
      const batch = db.batch();
      reviewsSnap.forEach((docSnap) => batch.delete(docSnap.ref));
      await batch.commit();
    }

    // 3. Delete the user's profile document and any subcollections (e.g. saved addresses).
    try {
      await db.recursiveDelete(db.collection('users').doc(uid));
    } catch (cleanupErr) {
      console.warn(`Failed to fully clean up Firestore data for user ${uid}:`, cleanupErr);
    }

    // 4. Finally, delete the Firebase Auth user record itself.
    await getAuth().deleteUser(uid);

    res.status(200).json({ success: true });
  } catch (err: any) {
    console.error('Account deletion failed:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to delete account' });
  }
});

app.post('/api/orders/:id/cancel', requireAuth, async (req: express.Request, res: express.Response) => {
  try {
    const orderId = req.params.id;
    const authUser = (req as any).authUser;
    const db = getFirestore();
    const orderRef = db.collection('orders').doc(orderId);
    const orderSnap = await orderRef.get();
    
    if (!orderSnap.exists) {
      return res.status(404).json({ success: false, error: 'Order not found' });
    }
    
    const orderData = orderSnap.data();
    if (orderData?.userId !== authUser.uid && !ADMIN_EMAILS.includes(authUser.email)) {
      return res.status(403).json({ success: false, error: 'Unauthorized to cancel this order' });
    }
    
    // Prevent cancellation if already dispatched
    const currentStatus = orderData?.status || orderData?.orderStatus;
    if (['dispatched', 'out_for_delivery', 'delivered', 'cancelled'].includes(currentStatus)) {
      return res.status(400).json({ success: false, error: 'Order cannot be cancelled at this stage' });
    }
    
    await orderRef.update({
      status: 'cancelled',
      orderStatus: 'cancelled',
      updatedAt: new Date().toISOString()
    });
    
    res.json({ success: true });
  } catch (e: any) {
    console.error('Cancel Order error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post('/api/orders/create', orderLimiter, optionalAuth, async (req: express.Request, res: express.Response) => {
    try {
      const parseResult = directOrderSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          error: parseResult.error.issues[0]?.message || 'Invalid order creation payload',
        });
      }

      const { items, shippingDetails, paymentMethod, utrNumber, couponCode } = parseResult.data;
      const authUser = (req as any).authUser;
      const userId = authUser ? authUser.uid : 'guest';

      const isWhatsAppExpress = paymentMethod === 'WhatsApp Express';

      // WhatsApp Express quick-orders don't collect a full delivery address up front
      // (the customer sends it in the WhatsApp chat), but every other payment method
      // still needs full, validated shipping details.
      if (!isWhatsAppExpress) {
        if (!shippingDetails.name?.trim()) {
          return res.status(400).json({ success: false, error: 'Name is required' });
        }
        if (!shippingDetails.phone || shippingDetails.phone.length < 10) {
          return res.status(400).json({ success: false, error: 'Valid phone number required' });
        }
        if (!shippingDetails.address?.trim()) {
          return res.status(400).json({ success: false, error: 'Address is required' });
        }
        if (!shippingDetails.pincode || shippingDetails.pincode.length < 6) {
          return res.status(400).json({ success: false, error: 'Valid pincode required' });
        }
      }
      // WhatsApp Express doesn't require a phone number here -- the quick
      // single-product flow collects it later via the WhatsApp chat itself.

      const { subtotal, validatedItems: safeItems } = await calculateOrderTotals(items);
      if (subtotal <= 0) {
        return res.status(400).json({ success: false, error: 'Order subtotal must be greater than zero' });
      }

      // Authoritative, server-side coupon discount (see applyCoupon()) -- the client
      // total shown at checkout is never trusted directly.
      let discountAmount = 0;
      let appliedCouponCode: string | null = null;
      if (couponCode) {
        try {
          const couponResult = await applyCoupon(subtotal, couponCode);
          discountAmount = couponResult.discountAmount;
          appliedCouponCode = couponResult.couponCode;
        } catch (couponErr: any) {
          return res.status(400).json({ success: false, error: couponErr.message || 'Invalid coupon code' });
        }
      }
      const discountedSubtotal = subtotal - discountAmount;

      const { deliveryFee, freeDeliveryThreshold } = await getStoreDeliverySettings();
      let effectiveDeliveryFee = deliveryFee;
      if (freeDeliveryThreshold > 0 && discountedSubtotal >= freeDeliveryThreshold) {
        effectiveDeliveryFee = 0;
      }

      const grandTotal = discountedSubtotal + effectiveDeliveryFee;
      const orderId = generateOrderId();

      // This endpoint never marks an order as paid -- online payments are only
      // confirmed via the Razorpay verify/webhook flow.
      const isPaidOnline = false;

      
      let initialStatus = 'pending';
      const initialPaymentStatus = 'unpaid';
      
      if (paymentMethod === 'WhatsApp Express') {
        initialStatus = 'whatsapp_pending';
      } else if (paymentMethod === 'Online Payment (UPI QR)') {
        initialStatus = 'paid_upi_pending_verify';
      }

      const orderPayload = {
        id: orderId,
        orderId: orderId,
        userId: userId || 'guest',
        items: safeItems,
        subtotal,
        discountAmount,
        couponCode: appliedCouponCode,
        deliveryFee: effectiveDeliveryFee,
        amount: grandTotal,
        grandTotal,
        shippingDetails,
        paymentMethod,
        orderStatus: initialStatus,
        status: initialStatus,
        paymentStatus: initialPaymentStatus,
        utrNumber: utrNumber || null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await getFirestore().collection('orders').doc(orderId).set(orderPayload);

      try {
        await decrementInventory(safeItems);
      } catch (stockErr: any) {
        // No payment captured yet for COD/WhatsApp, so it's safe to reject the order.
        await getFirestore().collection('orders').doc(orderId).update({
          status: 'cancelled',
          orderStatus: 'cancelled',
          cancelReason: stockErr.message || 'Insufficient stock',
          updatedAt: new Date().toISOString(),
        });
        return res.status(409).json({
          success: false,
          error: stockErr.message || 'One or more items just went out of stock. Please update your cart and try again.',
        });
      }

      return res.status(200).json({
        success: true,
        orderId,
        order: orderPayload,
      });
    } catch (err: any) {
      console.error('Failed to create direct order:', err);
      res.status(500).json({ success: false, error: err.message || 'Failed to create order on server' });
    }
  });

  // Server-side coupon validation, backed by the same `coupons` Firestore collection
  // the Admin Panel's Promotions tab writes to. Used by the cart UI to preview a
  // discount before checkout; the authoritative discount is still recomputed inside
  // /api/orders/create, /api/razorpay/order, and /api/razorpay/verify.
  app.post('/api/coupons/validate', orderLimiter, async (req: express.Request, res: express.Response) => {
    try {
      const parseResult = couponValidateSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          error: parseResult.error.issues[0]?.message || 'Invalid coupon request',
        });
      }
      const { code, items } = parseResult.data;
      const { subtotal } = await calculateOrderTotals(items);
      const { discountAmount, couponCode } = await applyCoupon(subtotal, code);

      const snap = await getFirestore().collection('coupons').doc(couponCode!).get();
      const coupon = snap.data() as any;

      return res.status(200).json({
        success: true,
        couponCode,
        discountAmount,
        discountType: coupon?.discountType,
        discountValue: coupon?.discountValue,
        description: coupon?.description,
        subtotal,
      });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message || 'Invalid coupon code' });
    }
  });

  // Secure Order Tracking Endpoint
  app.post('/api/orders/track', trackOrderLimiter, async (req: express.Request, res: express.Response) => {
    try {
      const parseResult = trackOrderSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          error: parseResult.error.issues[0]?.message || 'Invalid tracking parameters',
        });
      }

      const { orderId, phone } = parseResult.data;
      const docSnap = await getFirestore().collection('orders').doc(orderId).get();

      if (!docSnap.exists) {
        return res.status(404).json({ success: false, error: 'Order not found' });
      }

      const orderData = docSnap.data();
      const orderPhone = (orderData?.shippingDetails?.phone || '').replace(/\D/g, '');
      const inputPhone = (phone || '').replace(/\D/g, '');

      let authorized = false;
      const authHeader = req.headers.authorization || '';
      if (authHeader.startsWith('Bearer ')) {
        try {
          const token = authHeader.slice(7);
          const decoded = await getAuth().verifyIdToken(token);
          if (decoded.uid === orderData?.userId) {
            authorized = true;
          }
        } catch (authErr) {
          // Token verification error
        }
      }

      if (!authorized && inputPhone && orderPhone && orderPhone.endsWith(inputPhone.slice(-10))) {
        authorized = true;
      }

      if (!authorized) {
        return res.status(403).json({ success: false, error: 'Unauthorized to view this order' });
      }

      res.status(200).json({
        success: true,
        order: { id: docSnap.id, ...orderData },
      });
    } catch (err: any) {
      console.error('Order tracking error:', err);
      res.status(500).json({ success: false, error: 'Failed to retrieve order details' });
    }
  });

  const handleCreateOrder = async (req: express.Request, res: express.Response) => {
    try {
      const parseResult = createOrderSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          error: parseResult.error.issues[0]?.message || 'Invalid order payload',
        });
      }

      const { items, currency, couponCode, shippingDetails } = parseResult.data;
      const authUser = (req as any).authUser;
      const userId = authUser ? authUser.uid : 'guest';
      const { subtotal, validatedItems: safeItems } = await calculateOrderTotals(items);

      // Authoritative, server-side coupon discount -- applied before the Razorpay order
      // amount is calculated, so the customer is actually charged the discounted price.
      let discountAmount = 0;
      let appliedCouponCode: string | null = null;
      if (couponCode) {
        try {
          const couponResult = await applyCoupon(subtotal, couponCode);
          discountAmount = couponResult.discountAmount;
          appliedCouponCode = couponResult.couponCode;
        } catch (couponErr: any) {
          return res.status(400).json({ success: false, error: couponErr.message || 'Invalid coupon code' });
        }
      }
      const discountedSubtotal = subtotal - discountAmount;

      const { deliveryFee, freeDeliveryThreshold } = await getStoreDeliverySettings();
      
      let effectiveDeliveryFee = deliveryFee;
      if (freeDeliveryThreshold > 0 && discountedSubtotal >= freeDeliveryThreshold) {
        effectiveDeliveryFee = 0;
      }
      const totalAmount = discountedSubtotal + effectiveDeliveryFee;

      if (totalAmount <= 0) {
        return res.status(400).json({ success: false, error: 'Calculated order total must be greater than zero' });
      }

      const razorpayInstance = getRazorpay();
      if (razorpayInstance && env.RAZORPAY_KEY_ID) {
        const options = {
          amount: Math.round(totalAmount * 100), // convert rupees to paise
          currency: currency,
          receipt: `receipt_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
        };

        try {
          const order = await razorpayInstance.orders.create(options);

          // Snapshot everything needed to build the order later, keyed by the
          // Razorpay order id -- used by the webhook if /verify never completes.
          try {
            await getFirestore().collection('razorpayPendingOrders').doc(order.id).set({
              items: safeItems,
              subtotal,
              discountAmount,
              couponCode: appliedCouponCode,
              deliveryFee: effectiveDeliveryFee,
              amount: totalAmount,
              currency,
              shippingDetails: shippingDetails || {},
              userId,
              consumed: false,
              createdAt: new Date().toISOString(),
            });
          } catch (persistErr) {
            console.error('Failed to persist pending Razorpay order snapshot:', persistErr);
          }

          return res.status(200).json({
            success: true,
            order,
            key_id: env.RAZORPAY_KEY_ID,
            isLive: true,
          });
        } catch (e) {
          console.error('Razorpay API Error, falling back to UPI QR:', e);
        }
      }

      // Fallback response for direct online payment when Razorpay keys are not active
      return res.status(200).json({
        success: true,
        isFallback: true,
        upiId: 'paytm.s27lek5@pty',
        amount: totalAmount,
        order: {
          id: `order_upi_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
          amount: Math.round(totalAmount * 100),
          currency: currency,
        },
      });
    } catch (error: any) {
      console.error('Failed to create order:', error);
      res.status(500).json({ success: false, error: 'Internal order creation failure' });
    }
  };

  app.post('/api/razorpay/order', orderLimiter, optionalAuth, handleCreateOrder);

  // Verify Payment
  const handleVerifyPayment = async (req: express.Request, res: express.Response) => {
    try {
      const parseResult = verifyPaymentSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          error: parseResult.error.issues[0]?.message || 'Missing payment verification details',
        });
      }

      const { razorpay_order_id, razorpay_payment_id, razorpay_signature, items, shippingDetails, couponCode } = parseResult.data;
      const authUser = (req as any).authUser;
      const userId = authUser ? authUser.uid : 'guest';
      const secret = env.RAZORPAY_KEY_SECRET;

      if (!secret) {
        return res.status(500).json({ success: false, error: 'Razorpay secret key not configured on server' });
      }

      const generated_signature = crypto
        .createHmac('sha256', secret)
        .update(`${razorpay_order_id}|${razorpay_payment_id}`)
        .digest('hex');

      if (generated_signature !== razorpay_signature) {
        return res.status(400).json({ success: false, error: 'Invalid payment signature' });
      }

      // If items were provided, we should create the authoritative order record
      let orderId = null;
      if (items && items.length > 0) {
        // Avoid a duplicate if the webhook already reconstructed this order.
        const existingSnap = await getFirestore().collection('orders')
          .where('razorpay_order_id', '==', razorpay_order_id).limit(1).get();

        if (!existingSnap.empty) {
          orderId = existingSnap.docs[0].id;
        } else {
          // Claim the pending snapshot atomically -- if the webhook already claimed
          // it (racing this request), wait for its order instead of duplicating it.
          const claimed = await claimPendingRazorpayOrder(razorpay_order_id);
          if (!claimed) {
            orderId = await findOrderByRazorpayId(razorpay_order_id);
          } else {
            const { subtotal, validatedItems: safeItems } = await calculateOrderTotals(items);

            let discountAmount = 0;
            let appliedCouponCode: string | null = null;
            if (couponCode) {
              try {
                const couponResult = await applyCoupon(subtotal, couponCode);
                discountAmount = couponResult.discountAmount;
                appliedCouponCode = couponResult.couponCode;
              } catch (couponErr: any) {
                return res.status(400).json({ success: false, error: couponErr.message || 'Invalid coupon code' });
              }
            }
            const discountedSubtotal = subtotal - discountAmount;

            const { deliveryFee, freeDeliveryThreshold } = await getStoreDeliverySettings();
            let effectiveDeliveryFee = deliveryFee;
            if (freeDeliveryThreshold > 0 && discountedSubtotal >= freeDeliveryThreshold) {
              effectiveDeliveryFee = 0;
            }
            const grandTotal = discountedSubtotal + effectiveDeliveryFee;

            // Confirm the amount actually charged in Razorpay matches our computed total.
            const rzp = getRazorpay();
            if (rzp) {
              try {
                const rzpOrder = await rzp.orders.fetch(razorpay_order_id);
                if (rzpOrder.amount !== Math.round(grandTotal * 100)) {
                   return res.status(400).json({ success: false, error: 'Payment amount mismatch. Order items do not match payment.' });
                }
              } catch (fetchErr) {
                console.error('Failed to fetch Razorpay order for validation', fetchErr);
                return res.status(500).json({ success: false, error: 'Failed to validate payment amount' });
              }
            }
          
            const orderPayload = {
              items: safeItems,
              subtotal,
              discountAmount,
              couponCode: appliedCouponCode,
              deliveryFee: effectiveDeliveryFee,
              amount: grandTotal,
              grandTotal,
              status: 'confirmed',
              orderStatus: 'confirmed',
              paymentStatus: 'paid',
              paymentMethod: 'Online Payment (Razorpay)',
              razorpay_order_id,
              razorpay_payment_id,
              shippingDetails: shippingDetails || {},
              userId: userId || null,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };

            orderId = generateOrderId();
            (orderPayload as any).id = orderId;
            (orderPayload as any).orderId = orderId;

            try {
              await getFirestore().collection('orders').doc(orderId).set(orderPayload);
              try {
                await decrementInventory(safeItems);
              } catch (stockErr: any) {
                // Payment was already captured -- we can't reject the order, but flag it
                // so an admin can follow up (e.g. partial refund or backorder), instead of
                // silently overselling with no record of the conflict.
                console.error(`[Verify] Inventory conflict on paid order ${orderId}:`, stockErr.message);
                await getFirestore().collection('orders').doc(orderId).update({
                  stockConflict: true,
                  stockConflictReason: stockErr.message,
                });
              }
            } catch (dbErr) {
              console.warn('Failed to save verified order to Firestore on server:', dbErr);
            }
          }
        }
      }

      res.status(200).json({ 
        success: true, 
        message: 'Payment verified successfully',
        orderId: orderId
      });
    } catch (error: any) {
      console.error('Failed to verify Razorpay signature:', error);
      res.status(500).json({ success: false, error: 'Payment verification failed' });
    }
  };

  app.post('/api/razorpay/verify', optionalAuth, handleVerifyPayment);

  // Webhook Handling
  const handleWebhook = async (req: express.Request, res: express.Response) => {
    try {
      const webhookSecret = env.RAZORPAY_WEBHOOK_SECRET;

      // SECURITY: Fail closed, not open. This endpoint is public (Razorpay
      // can't send an auth token), so signature verification is the only
      // thing standing between a real payment event and a forged one. If
      // the secret is missing, reject rather than silently trusting
      // unverified payloads -- an attacker could otherwise POST a fake
      // "payment.captured" event and get an order marked paid for free.
      if (!webhookSecret) {
        console.error('[Webhook] RAZORPAY_WEBHOOK_SECRET is not configured -- rejecting webhook rather than processing it unverified.');
        return res.status(500).json({ success: false, error: 'Webhook verification not configured' });
      }

      const signature = req.headers['x-razorpay-signature'] as string;
      if (!signature) {
        return res.status(400).json({ success: false, error: 'Missing webhook signature' });
      }

      const expectedSignature = crypto
        .createHmac('sha256', webhookSecret)
        .update((req as any).rawBody || '')
        .digest('hex');

      if (signature !== expectedSignature) {
        return res.status(400).json({ success: false, error: 'Invalid webhook signature' });
      }

      const event = req.body?.event;
      const payload = req.body?.payload;
      console.log(`[Webhook Received]: ${event}`);

      // Respond 200 immediately after validating the signature, then reconcile.
      // Razorpay retries on non-2xx / timeout, so ack first and let reconciliation
      // errors be logged rather than causing pointless webhook retries.
      res.status(200).json({ success: true });

      if (event === 'payment.captured' || event === 'order.paid') {
        const paymentEntity = payload?.payment?.entity;
        const razorpayOrderId = paymentEntity?.order_id || payload?.order?.entity?.id;
        const paymentId = paymentEntity?.id || null;
        if (razorpayOrderId) {
          try {
            await reconcileRazorpayOrder(razorpayOrderId, paymentId);
          } catch (reconcileErr) {
            console.error(`[Webhook] Reconciliation failed for Razorpay order ${razorpayOrderId}:`, reconcileErr);
          }
        } else {
          console.warn(`[Webhook] ${event} event received without a resolvable order id.`);
        }
      }
      return;
    } catch (error: any) {
      console.error('Webhook processing failed:', error.message || error);
      res.status(500).json({ success: false, error: 'Webhook processing failed' });
    }
  };

  app.post('/api/razorpay/webhook', handleWebhook);

  // Serve static public assets
  const publicUploads = path.join(process.cwd(), 'public', 'uploads');
  app.use('/uploads', express.static(publicUploads));

  // Push Notifications
  app.post('/api/send-notification', strictApiLimiter, requireAuth, requireAdmin, async (req: express.Request, res: express.Response) => {
    try {
      const parseResult = sendNotificationSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          error: parseResult.error.issues[0]?.message || 'Invalid notification payload',
        });
      }

      const { tokens, userId, title, body, data } = parseResult.data;

      if (!getApps().length) {
        return res.status(500).json({ success: false, error: 'Firebase Admin not initialized' });
      }

      let targetTokens: string[] = [];

      if (tokens) {
        targetTokens = Array.isArray(tokens) ? tokens : [tokens];
      } else if (userId) {
        const userDoc = await getFirestore().collection('users').doc(userId).get();
        if (userDoc.exists) {
          const userData = userDoc.data();
          if (userData && Array.isArray(userData.fcmTokens) && userData.fcmTokens.length > 0) {
            targetTokens = userData.fcmTokens;
          }
        }
      }

      if (targetTokens.length === 0) {
        return res.status(200).json({ success: true, message: 'No devices to notify' });
      }

      const message = {
        notification: { title, body },
        data: data || {},
        tokens: targetTokens,
      };

      const response = await getMessaging().sendEachForMulticast(message);
      res.status(200).json({ success: true, response });
    } catch (error: any) {
      console.error('Push Notification Error:', error);
      res.status(500).json({ success: false, error: error.message || 'Failed to send notification' });
    }
  });

  // Order Email Sender
  app.post('/api/send-order-email', strictApiLimiter, requireAuth, async (req: express.Request, res: express.Response) => {
    try {
      const parseResult = sendEmailSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          error: parseResult.error.issues[0]?.message || 'Invalid email request payload',
        });
      }

      const { email, order, storeName } = parseResult.data;

      const authUser = (req as any).authUser;
      if (authUser.email !== email) {
        return res.status(403).json({ success: false, error: 'Cannot send email on behalf of another user' });
      }

      const host = env.SMTP_HOST;
      const port = parseInt(env.SMTP_PORT || '587', 10);
      const user = env.SMTP_USER;
      const pass = env.SMTP_PASS;
      const from = env.SMTP_FROM || `"${sanitizeHTML(storeName)}" <noreply@example.com>`;

      if (!host || !user || !pass) {
        console.log('No SMTP config found. Mocking email to:', email, 'for order:', order.id || 'unknown');
        return res.status(200).json({ success: true, message: 'Email sent (mock)', isMock: true });
      }

      const transporter = nodemailer.createTransport({
        host,
        port,
        secure: port === 465,
        auth: { user, pass },
      });

      // Escape dynamic input values to prevent HTML injection / XSS
      const itemsList = (order.items || [])
        .map(
          (item: any) =>
            `<li style="padding: 8px 0; border-bottom: 1px solid #eee;">${Number(item.quantity)}x ${sanitizeHTML(
              item.name
            )} <span style="float: right;">₹${Number(item.price) * Number(item.quantity)}</span></li>`
        )
        .join('');

      const mailOptions = {
        from,
        to: email,
        subject: `Order Confirmation - ${sanitizeHTML(storeName)}`,
        html: `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; color: #333; padding: 20px;">
            <h2 style="color: #111;">Thank you for your order!</h2>
            <p>Hi ${sanitizeHTML(order.shippingDetails?.name || 'Customer')},</p>
            <p>We've received your order and are getting it ready for you.</p>
            
            <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="margin-top: 0; border-bottom: 1px solid #ddd; padding-bottom: 10px;">Order Summary</h3>
              <ul style="list-style: none; padding: 0; margin: 0;">
                ${itemsList}
              </ul>
              <div style="border-top: 1px solid #ddd; margin-top: 10px; padding-top: 10px; font-weight: bold; text-align: right;">
                Total: ₹${Number(order.amount || 0)}
              </div>
            </div>
            
            <p><strong>Shipping Address:</strong><br>
              ${sanitizeHTML(order.shippingDetails?.address || 'N/A')}<br>
              Phone: ${sanitizeHTML(order.shippingDetails?.phone || 'N/A')}
            </p>
            
            <p>If you have any questions, please contact our support team.</p>
            <p>Best regards,<br>${sanitizeHTML(storeName)}</p>
          </div>
        `,
      };

      await transporter.sendMail(mailOptions);
      res.status(200).json({ success: true });
    } catch (error: any) {
      console.error('Email sending error:', error?.message || error);
      res.status(500).json({ success: false, error: 'Failed to send email' });
    }
  });

  // Vite Middleware in Dev vs Static Serving in Production.
  // On Vercel, static files and the SPA catch-all are served by Vercel's own
  // CDN/rewrites (see vercel.json) -- this Express app only ever handles
  // /api/* there, so the static-serving branch below is skipped in that
  // environment and only runs for traditional Node hosts (Render, a VPS, etc).
  const isServerless = !!process.env.VERCEL;

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else if (!isServerless) {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(
      express.static(distPath, {
        setHeaders: (res, path) => {
          if (path.endsWith('.html')) {
            res.setHeader('Cache-Control', 'no-cache');
          } else {
            res.setHeader('Cache-Control', 'public, max-age=31536000');
          }
        },
      })
    );
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Must be the last app.use() -- error middleware only catches errors from
  // handlers registered before it.
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error('Unhandled server error:', err.message || err);
    if (res.headersSent) return next(err);
    res.status(500).json({ success: false, error: 'Internal server error' });
  });

  return app;
}

// Vercel (and other serverless platforms) import this module for its default
// export -- a request handler -- and invoke it per-request; it must NEVER
// call app.listen() there, since serverless functions don't own a persistent
// port. Traditional Node hosts (Render, Railway, a VPS) run `npm start`,
// which executes this file directly and needs the real app.listen() call.
let appPromise: ReturnType<typeof startServer> | null = null;
function getApp() {
  if (!appPromise) appPromise = startServer();
  return appPromise;
}

if (!process.env.VERCEL) {
  // Traditional long-running server (Render/Railway/VPS/local dev).
  getApp()
    .then((app) => {
      app.listen(PORT, '0.0.0.0', () => {
        console.log(`Server running on http://0.0.0.0:${PORT}`);
      });
    })
    .catch((err) => {
      console.error('Failed to start server:', err);
      process.exit(1);
    });
}

// Serverless entry point (Vercel). Each invocation reuses the same warm
// `app` instance across requests when the function stays warm, same as any
// other Express-on-serverless deployment.
export default async function handler(req: express.Request, res: express.Response) {
  const app = await getApp();
  return app(req, res);
}

