# Changelog

## [1.0.1] - 2026-08-02
### Fixed
- **CRITICAL**: Fixed TypeScript errors by replacing `any` types with appropriate types in `src/types/index.ts`.
- **CRITICAL**: Fixed Firebase initialization to use environment variables instead of hardcoded API keys and secrets in `src/services/firebase.ts`.
- **HIGH**: Added `engines` field in `package.json` to enforce Node >= 20.19.0.
- **HIGH**: Removed AI Studio boilerplate files (`metadata.json`, `firebase-applet-config.json`, `firebase-blueprint.json`).
- **HIGH**: Wrote missing documentation: `README.md`, `SETUP.md`, `ARCHITECTURE.md`.
- **MEDIUM**: Cleaned up commented out blocks and console logs where appropriate.
